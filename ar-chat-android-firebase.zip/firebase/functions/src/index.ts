import * as admin from 'firebase-admin';
import { onDocumentCreated } from 'firebase-functions/v2/firestore';
import { onValueWritten } from 'firebase-functions/v2/database';
import * as functionsV1 from 'firebase-functions/v1';

admin.initializeApp();

const db = admin.firestore();
const messaging = admin.messaging();

// Configure named database ID if deploying to a non-default database;
// leave undefined for standard "(default)" Firestore deployments.
const FIRESTORE_DATABASE_ID = process.env.FIRESTORE_DATABASE_ID || '';
const targetDb = FIRESTORE_DATABASE_ID
  ? admin.firestore(admin.app(), FIRESTORE_DATABASE_ID)
  : db;

interface MessageDoc {
  messageId: string;
  senderId: string;
  senderName: string;
  senderPhotoUrl?: string;
  type: 'text' | 'image' | 'audio';
  text: string;
  isDeletedForEveryone?: boolean;
}

interface UserPrivateInfo {
  notifyPrivateMessages?: boolean;
  notifyGroupMessages?: boolean;
  notifyChatInvites?: boolean;
  showMessagePreview?: boolean;
}

/**
 * Helper to fetch all FCM tokens for a user and remove invalid/unregistered tokens.
 */
async function sendFcmToUser(
  recipientUid: string,
  payload: {
    title: string;
    body: string;
    imageUrl?: string;
    channelId: string;
    data: Record<string, string>;
  }
): Promise<void> {
  const tokensSnap = await targetDb
    .collection('userDevices')
    .doc(recipientUid)
    .collection('tokens')
    .get();

  if (tokensSnap.empty) return;

  const tokenDocs = tokensSnap.docs;
  const tokens = tokenDocs
    .map((doc) => doc.data().token as string | undefined)
    .filter((t): t is string => Boolean(t && t.length > 10));

  if (tokens.length === 0) return;

  const response = await messaging.sendEachForMulticast({
    tokens,
    notification: {
      title: payload.title,
      body: payload.body,
      ...(payload.imageUrl ? { imageUrl: payload.imageUrl } : {}),
    },
    android: {
      priority: 'high',
      notification: {
        channelId: payload.channelId,
        clickAction: 'OPEN_CHAT_FROM_NOTIFICATION',
        defaultSound: true,
        defaultVibrateTimings: true,
      },
    },
    data: payload.data,
  });

  // Clean up invalid or expired device tokens
  const cleanupPromises: Promise<FirebaseFirestore.WriteResult>[] = [];
  response.responses.forEach((res, idx) => {
    if (!res.success && res.error) {
      const code = res.error.code;
      if (
        code === 'messaging/invalid-registration-token' ||
        code === 'messaging/registration-token-not-registered'
      ) {
        cleanupPromises.push(tokenDocs[idx].ref.delete());
      }
    }
  });

  if (cleanupPromises.length > 0) {
    await Promise.all(cleanupPromises);
  }
}

function buildMessagePreview(message: MessageDoc, showPreview: boolean): string {
  if (!showPreview) return 'Sent you a new message';
  if (message.type === 'image') return '📷 Photo';
  if (message.type === 'audio') return '🎙️ Voice message';
  const trimmed = (message.text || '').trim();
  return trimmed.length > 120 ? `${trimmed.slice(0, 117)}...` : trimmed || 'New message';
}

/**
 * 1. Private Message Trigger:
 *    - Verifies block status
 *    - Respects recipient notification preferences
 *    - Sends FCM push notification with deep link data
 *    - Creates in-app notification record
 */
export const onPrivateMessageCreated = onDocumentCreated(
  'chats/{chatId}/messages/{messageId}',
  async (event) => {
    const snap = event.data;
    if (!snap) return;

    const { chatId, messageId } = event.params;
    const message = snap.data() as MessageDoc;
    if (!message || message.isDeletedForEveryone) return;

    const chatSnap = await targetDb.collection('chats').doc(chatId).get();
    if (!chatSnap.exists) return;

    const chatData = chatSnap.data();
    const participants = (chatData?.participants as string[]) || [];
    const recipientUid = participants.find((uid) => uid !== message.senderId);
    if (!recipientUid) return;

    // Enforce block rule server-side
    const blockedDoc = await targetDb
      .collection('blockedUsers')
      .doc(recipientUid)
      .collection('blocked')
      .doc(message.senderId)
      .get();
    if (blockedDoc.exists) return;

    // Check recipient notification preferences
    const privateInfoSnap = await targetDb
      .collection('users')
      .doc(recipientUid)
      .collection('private')
      .doc('info')
      .get();
    const prefs = (privateInfoSnap.data() as UserPrivateInfo | undefined) || {};
    if (prefs.notifyPrivateMessages === false) return;

    const preview = buildMessagePreview(message, prefs.showMessagePreview !== false);

    // Record in-app notification item
    const notificationId = `${chatId}_${messageId}`;
    await targetDb
      .collection('notifications')
      .doc(recipientUid)
      .collection('items')
      .doc(notificationId)
      .set({
        notificationId,
        recipientUid,
        type: 'private_message',
        title: message.senderName || 'New message',
        body: preview,
        targetId: chatId,
        isRead: false,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

    await sendFcmToUser(recipientUid, {
      title: message.senderName || 'AR Chat',
      body: preview,
      imageUrl: message.senderPhotoUrl || undefined,
      channelId: 'messages_private',
      data: {
        chatType: 'private',
        chatId,
        messageId,
        senderId: message.senderId,
        senderName: message.senderName || 'AR Chat',
        senderPhotoUrl: message.senderPhotoUrl || '',
      },
    });
  }
);

/**
 * 2. Group Message Trigger:
 *    - Fetches group members and mute settings
 *    - Sends FCM push notification to unmuted non-sender members
 */
export const onGroupMessageCreated = onDocumentCreated(
  'groups/{groupId}/messages/{messageId}',
  async (event) => {
    const snap = event.data;
    if (!snap) return;

    const { groupId, messageId } = event.params;
    const message = snap.data() as MessageDoc;
    if (!message || message.isDeletedForEveryone) return;

    const groupSnap = await targetDb.collection('groups').doc(groupId).get();
    if (!groupSnap.exists) return;

    const groupData = groupSnap.data();
    const groupName = (groupData?.name as string) || 'Group Chat';
    const groupPhotoUrl = (groupData?.photoUrl as string) || '';

    const membersSnap = await targetDb
      .collection('groups')
      .doc(groupId)
      .collection('members')
      .get();

    const tasks = membersSnap.docs.map(async (memberDoc) => {
      const member = memberDoc.data();
      const memberUid = member.uid as string;
      if (!memberUid || memberUid === message.senderId || member.muted === true) {
        return;
      }

      const privateInfoSnap = await targetDb
        .collection('users')
        .doc(memberUid)
        .collection('private')
        .doc('info')
        .get();
      const prefs = (privateInfoSnap.data() as UserPrivateInfo | undefined) || {};
      if (prefs.notifyGroupMessages === false) return;

      const preview = buildMessagePreview(message, prefs.showMessagePreview !== false);
      const body = `${message.senderName}: ${preview}`;

      await sendFcmToUser(memberUid, {
        title: groupName,
        body,
        imageUrl: groupPhotoUrl || message.senderPhotoUrl || undefined,
        channelId: 'messages_group',
        data: {
          chatType: 'group',
          chatId: groupId,
          groupName,
          messageId,
          senderId: message.senderId,
          senderName: message.senderName || 'Member',
        },
      });
    });

    await Promise.all(tasks);
  }
);

/**
 * 3. Group Member Added / Chat Invite Notification Trigger
 */
export const onGroupMemberAdded = onDocumentCreated(
  'groups/{groupId}/members/{memberId}',
  async (event) => {
    const snap = event.data;
    if (!snap) return;

    const { groupId, memberId } = event.params;
    const groupSnap = await targetDb.collection('groups').doc(groupId).get();
    if (!groupSnap.exists) return;

    const groupData = groupSnap.data();
    if (groupData?.createdBy === memberId) return; // Skip notifying group creator

    const groupName = (groupData?.name as string) || 'a group';
    const privateInfoSnap = await targetDb
      .collection('users')
      .doc(memberId)
      .collection('private')
      .doc('info')
      .get();
    const prefs = (privateInfoSnap.data() as UserPrivateInfo | undefined) || {};
    if (prefs.notifyChatInvites === false) return;

    const notificationId = `invite_${groupId}_${memberId}`;
    await targetDb
      .collection('notifications')
      .doc(memberId)
      .collection('items')
      .doc(notificationId)
      .set({
        notificationId,
        recipientUid: memberId,
        type: 'group_invite',
        title: 'Added to group',
        body: `You were added to ${groupName}`,
        targetId: groupId,
        isRead: false,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

    await sendFcmToUser(memberId, {
      title: 'AR Chat Group Invite',
      body: `You were added to ${groupName}`,
      channelId: 'chat_invites',
      data: {
        chatType: 'group',
        chatId: groupId,
        groupName,
      },
    });
  }
);

/**
 * 4. Realtime Database -> Firestore Presence Mirror:
 *    Synchronizes instant RTDB .info/connected + onDisconnect() presence into users/{uid}.
 */
export const syncRtdbPresenceToFirestore = onValueWritten(
  '/presence/{uid}',
  async (event) => {
    const uid = event.params.uid;
    const afterVal = event.data.after.val() as { online?: boolean; lastChanged?: number } | null;
    if (!afterVal) return;

    const userRef = targetDb.collection('users').doc(uid);
    const userSnap = await userRef.get();
    if (!userSnap.exists) return;

    const isOnline = afterVal.online === true;
    await userRef.update({
      isOnline,
      lastSeen: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }
);

/**
 * 5. Account Cleanup on Firebase Auth User Deletion
 */
export const onAuthUserDeleted = functionsV1.auth.user().onDelete(async (user) => {
  const uid = user.uid;
  const userRef = targetDb.collection('users').doc(uid);
  const userSnap = await userRef.get();

  const batch = targetDb.batch();

  if (userSnap.exists) {
    const username = userSnap.data()?.username as string | undefined;
    if (username) {
      batch.delete(targetDb.collection('usernames').doc(username));
    }
    batch.delete(userRef);
  }

  batch.delete(userRef.collection('private').doc('info'));

  const tokensSnap = await targetDb.collection('userDevices').doc(uid).collection('tokens').get();
  tokensSnap.docs.forEach((d) => batch.delete(d.ref));

  const contactsSnap = await targetDb.collection('userContacts').doc(uid).collection('contacts').get();
  contactsSnap.docs.forEach((d) => batch.delete(d.ref));

  const blockedSnap = await targetDb.collection('blockedUsers').doc(uid).collection('blocked').get();
  blockedSnap.docs.forEach((d) => batch.delete(d.ref));

  await batch.commit();

  try {
    await admin.database().ref(`/presence/${uid}`).remove();
  } catch {
    // RTDB may not be initialized if user hasn't enabled it yet
  }
});
