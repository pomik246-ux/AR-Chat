# AR Chat — Complete Firebase Setup & Android APK Build Guide

This guide covers connecting the native Android Studio project (`/android`) and Firebase backend (`/firebase` + `/firestore.rules`) to your Firebase project, plus building Debug and Release APKs.

> **Note on AI Studio Provisioned Project:**
> AI Studio has already provisioned a live Firestore database and Firebase project (`upbeat-falcon-nq7xb`, database ID `ai-studio-d5458b6a-3d7c-424d-8280-25e1f0bf44dc`) and deployed `firestore.rules` for the interactive Web Preview. To connect your native Android APK to either this existing project or a brand-new Firebase project named **AR Chat**, follow the exact steps below.

---

## Part 1: Step-by-Step Firebase Setup (18 Steps)

### 1. Create (or Open) Firebase Project Named "AR Chat"
1. Go to [https://console.firebase.google.com](https://console.firebase.google.com).
2. Click **Add project** (or select your existing provisioned project `upbeat-falcon-nq7xb`).
3. Enter project name: **AR Chat**.
4. Optionally enable Google Analytics and click **Create project**.

### 2. Add Android App to Firebase
1. In the Firebase Console **Project Overview**, click the **Android** icon (`+ Add app`).
2. Fill in:
   - **Android package name:** `com.archat.app` *(exact match required — matches `applicationId` in `android/app/build.gradle.kts`)*
   - **App nickname:** `AR Chat Android`
   - **Debug signing certificate SHA-1:** Run `./gradlew signingReport` inside `/android` (or `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android`) and paste the SHA-1 value.

### 3. Exact Android Package Name
- **`com.archat.app`**
- Defined in:
  - `android/app/build.gradle.kts` (`namespace = "com.archat.app"`, `applicationId = "com.archat.app"`)
  - `android/app/src/main/AndroidManifest.xml`
  - All Kotlin packages under `android/app/src/main/java/com/archat/app/`

### 4. Download `google-services.json`
1. In the Firebase setup wizard (or **Project Settings → General → Your apps → Android**), click **Download google-services.json**.

### 5. Place `google-services.json` in the Correct Android Folder
1. Move the downloaded file to:
   ```
   android/app/google-services.json
   ```
2. A reference template is provided at `android/app/google-services.json.template`. **Do not leave it as `.template`** — the Gradle Google Services plugin requires the exact filename `android/app/google-services.json`.

### 6. Enable Firebase Authentication
1. In Firebase Console, open **Build → Authentication** and click **Get started**.

### 7. Enable Email/Password Provider
1. Under **Authentication → Sign-in method**, click **Email/Password**.
2. Toggle **Enable** (leave "Email link (passwordless sign-in)" off unless desired) and click **Save**.
3. *(Optional for Web Preview)* Also enable **Google** sign-in provider if testing Google Sign-In on Web.

### 8. Configure Email Verification
1. Email verification works automatically with Firebase Auth (`user.sendEmailVerification()`).
2. Customize the verification & password reset templates in **Authentication → Templates** (sender name: `AR Chat`, subject: `Verify your AR Chat email`).
3. Ensure your authorized domains under **Authentication → Settings → Authorized domains** include your app domain (`upbeat-falcon-nq7xb.firebaseapp.com`).

### 9. Create Cloud Firestore Database
1. Open **Build → Firestore Database → Create database**.
2. Choose **Standard edition** (or use the provisioned database ID).
3. Select your nearest region (e.g., `us-central1` or `asia-east1`) and start in **Production mode**.
4. **Important:** In `android/app/build.gradle.kts`, check `FIRESTORE_DATABASE_ID`:
   - If you use the AI Studio provisioned database, keep `"ai-studio-d5458b6a-3d7c-424d-8280-25e1f0bf44dc"`.
   - If you created a fresh standard `(default)` database in a new Firebase project, set `FIRESTORE_DATABASE_ID` to `""`.

### 10. Configure Firebase Storage
1. Open **Build → Storage → Get started**.
2. Start in **Production mode** and select the same region as Firestore.

### 11. Set Up Firebase Cloud Messaging (FCM)
1. FCM is automatically enabled when `google-services.json` is added and `com.google.firebase:firebase-messaging-ktx` is included.
2. In **Project Settings → Cloud Messaging**, verify **Firebase Cloud Messaging API (V1)** is **Enabled**.
3. In Android (`ARChatMessagingService.kt`), notification channels (`messages_private`, `messages_group`, `chat_invites`) and runtime `POST_NOTIFICATIONS` permission (Android 13+) are already wired.

### 12. Set Up Firebase Realtime Database for Presence
1. Open **Build → Realtime Database → Create Database**.
2. Select a region and start in **Locked mode**.
3. Ensure your `google-services.json` is re-downloaded after creating RTDB so `firebase_url` is populated in `project_info`.
4. Deploy `firebase/database.rules.json` (see Step 14/15).

### 13. Deploy Cloud Functions
1. Install Firebase CLI: `npm install -g firebase-tools`
2. Authenticate: `firebase login`
3. Inside `firebase/`:
   ```bash
   cd firebase/functions
   npm install
   npm run build
   cd ..
   firebase use <your-project-id>
   firebase deploy --only functions
   ```
4. *(If using the named Firestore database ID)* Set the environment variable before deploying or via `.env`:
   `FIRESTORE_DATABASE_ID=ai-studio-d5458b6a-3d7c-424d-8280-25e1f0bf44dc`

### 14. Deploy Firestore Rules
```bash
cd firebase
firebase deploy --only firestore:rules
```
*(Root `/firestore.rules` is already referenced by `firebase/firebase.json`.)*

### 15. Deploy Storage & Realtime Database Rules
```bash
cd firebase
firebase deploy --only storage,database
```

### 16. Create Required Firestore Indexes
```bash
cd firebase
firebase deploy --only firestore:indexes
```
This creates composite indexes for:
- `chats` (`participants` CONTAINS, `lastMessageAt` DESC)
- `groups` (`memberIds` CONTAINS, `lastMessageAt` DESC)
- `messages` (`createdAt` DESC)
- `users` (`usernameLower` ASC, `displayNameLower` ASC)
- `items` (`isRead` ASC, `createdAt` DESC)

### 17. Configure Firebase App Check
1. Open **Build → App Check → Apps**.
2. Click your Android app (`com.archat.app`) → Register **Play Integrity** (for release builds distributed via Google Play).
3. For local Debug APK testing on an emulator or physical phone:
   - Run the debug build in Android Studio Logcat and filter for `DebugAppCheckProvider`.
   - Copy the printed UUID debug secret token.
   - In Firebase Console → **App Check → Apps → Manage debug tokens**, add that token.
4. Once verified, click **Enforce** on Cloud Firestore, Cloud Storage, and Realtime Database.

### 18. Billing Requirements & Free-Tier Limitations
- **Spark Plan (Free Tier) Includes:**
  - **Authentication:** Free up to 50,000 MAUs (Email/Password is free).
  - **Firestore:** 50,000 reads/day, 20,000 writes/day, 20,000 deletes/day, 1 GiB storage.
  - **Realtime Database:** 1 GB stored, 10 GB/month downloaded, 100 simultaneous connections.
  - **FCM Push Notifications:** Completely free and unlimited.
- **Blaze Plan (Pay-as-you-go) Required For:**
  - **Firebase Cloud Functions (Node 20 / v2)** requires upgrading the project to the **Blaze plan** (a billing account must be attached, though you still receive 2,000,000 free function invocations/month and 5 GB free Cloud Storage).
  - **Cloud Storage** in newer regions/projects also requires the Blaze plan (with a generous no-cost monthly tier).

---

## Part 2: Building the Android APK

### Prerequisites
- Android Studio Ladybug / Meerkat (2024.2+)
- JDK 17
- Android SDK Platform 35 & Build-Tools 35.0.0
- `android/app/google-services.json` placed in `android/app/`

### Build Debug APK (for Direct Phone Installation)
1. Open the `/android` folder in **Android Studio**.
2. Wait for Gradle Sync to finish.
3. Connect an Android phone (USB Debugging enabled) and click **Run ▶**, OR build the installable APK from terminal:
   ```bash
   cd android
   ./gradlew assembleDebug
   ```
4. Output APK location:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```
5. Install directly via ADB:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

### Build Signed Release APK
1. Generate a release keystore (keep this private and never commit it):
   ```bash
   keytool -genkey -v -keystore ar-chat-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias archat
   ```
2. In Android Studio: **Build → Generate Signed Bundle / APK → APK → Next**, select `ar-chat-release.jks`, choose **release** build variant, and click **Create**.
3. Or via CLI after configuring `signingConfigs` in `app/build.gradle.kts`:
   ```bash
   cd android
   ./gradlew assembleRelease
   ```
4. Output APK location:
   ```
   android/app/build/outputs/apk/release/app-release.apk
   ```
