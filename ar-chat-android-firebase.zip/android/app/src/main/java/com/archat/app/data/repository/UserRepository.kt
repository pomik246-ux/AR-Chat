package com.archat.app.data.repository

import android.net.Uri
import com.archat.app.data.model.BlockedUser
import com.archat.app.data.model.UserContact
import com.archat.app.data.model.UserPrivateInfo
import com.archat.app.data.model.UserProfile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class UserRepository(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
    private val storageRepository: StorageRepository
) {
    fun currentUid(): String? = auth.currentUser?.uid

    fun observeUserProfile(uid: String): Flow<UserProfile?> = callbackFlow {
        val registration = firestore.collection("users").document(uid)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    trySend(null)
                    return@addSnapshotListener
                }
                trySend(snap?.toObject(UserProfile::class.java))
            }
        awaitClose { registration.remove() }
    }

    fun observePrivateInfo(uid: String): Flow<UserPrivateInfo?> = callbackFlow {
        val registration = firestore.collection("users").document(uid)
            .collection("private").document("info")
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    trySend(null)
                    return@addSnapshotListener
                }
                trySend(snap?.toObject(UserPrivateInfo::class.java))
            }
        awaitClose { registration.remove() }
    }

    suspend fun getUserProfile(uid: String): Result<UserProfile?> = runCatching {
        firestore.collection("users").document(uid).get().await()
            .toObject(UserProfile::class.java)
    }

    suspend fun searchUsers(query: String): Result<List<UserProfile>> = runCatching {
        val clean = query.trim().lowercase()
        val myUid = currentUid()
        if (clean.isEmpty()) {
            val snap = firestore.collection("users")
                .orderBy("displayNameLower")
                .limit(30)
                .get()
                .await()
            snap.toObjects(UserProfile::class.java).filter { it.uid != myUid }
        } else {
            val byUsername = firestore.collection("users")
                .orderBy("usernameLower")
                .startAt(clean)
                .endAt(clean + "\uf8ff")
                .limit(20)
                .get()
                .await()
                .toObjects(UserProfile::class.java)

            val byName = firestore.collection("users")
                .orderBy("displayNameLower")
                .startAt(clean)
                .endAt(clean + "\uf8ff")
                .limit(20)
                .get()
                .await()
                .toObjects(UserProfile::class.java)

            (byUsername + byName)
                .distinctBy { it.uid }
                .filter { it.uid != myUid }
        }
    }

    suspend fun updateProfile(displayName: String, bio: String, newPhotoUri: Uri?): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        val cleanName = displayName.trim()
        val cleanBio = bio.trim().take(200)

        val updates = mutableMapOf<String, Any>(
            "displayName" to cleanName,
            "displayNameLower" to cleanName.lowercase(),
            "bio" to cleanBio,
            "updatedAt" to FieldValue.serverTimestamp()
        )

        if (newPhotoUri != null) {
            val url = storageRepository.uploadProfilePhoto(uid, newPhotoUri).getOrThrow()
            updates["photoUrl"] = url
        }

        firestore.collection("users").document(uid).update(updates).await()
    }

    suspend fun updatePrivacySettings(
        showLastSeen: String,
        showOnline: Boolean,
        showPhoto: String,
        whoCanMessage: String
    ): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        firestore.collection("users").document(uid).update(
            mapOf(
                "privacyShowLastSeen" to showLastSeen,
                "privacyShowOnline" to showOnline,
                "privacyShowPhoto" to showPhoto,
                "privacyWhoCanMessage" to whoCanMessage,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun updateNotificationPreferences(
        notifyPrivate: Boolean,
        notifyGroup: Boolean,
        notifyInvites: Boolean,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean,
        showPreview: Boolean
    ): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        firestore.collection("users").document(uid)
            .collection("private").document("info")
            .update(
                mapOf(
                    "notifyPrivateMessages" to notifyPrivate,
                    "notifyGroupMessages" to notifyGroup,
                    "notifyChatInvites" to notifyInvites,
                    "soundEnabled" to soundEnabled,
                    "vibrationEnabled" to vibrationEnabled,
                    "showMessagePreview" to showPreview,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
    }

    fun observeContacts(): Flow<List<UserContact>> = callbackFlow {
        val uid = currentUid() ?: run {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val reg = firestore.collection("userContacts").document(uid)
            .collection("contacts")
            .orderBy("displayName")
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(UserContact::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun addContact(peer: UserProfile, isFavorite: Boolean = false): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        firestore.collection("userContacts").document(uid)
            .collection("contacts").document(peer.uid)
            .set(
                mapOf(
                    "contactUid" to peer.uid,
                    "ownerUid" to uid,
                    "displayName" to peer.displayName,
                    "username" to peer.username,
                    "photoUrl" to peer.photoUrl,
                    "isFavorite" to isFavorite,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
    }

    suspend fun toggleFavoriteContact(contactUid: String, favorite: Boolean): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        firestore.collection("userContacts").document(uid)
            .collection("contacts").document(contactUid)
            .update("isFavorite", favorite).await()
    }

    suspend fun removeContact(contactUid: String): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        firestore.collection("userContacts").document(uid)
            .collection("contacts").document(contactUid)
            .delete().await()
    }

    fun observeBlockedUsers(): Flow<List<BlockedUser>> = callbackFlow {
        val uid = currentUid() ?: run {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val reg = firestore.collection("blockedUsers").document(uid)
            .collection("blocked")
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(BlockedUser::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun isBlockedEitherWay(peerUid: String): Boolean {
        val uid = currentUid() ?: return false
        val iBlocked = firestore.collection("blockedUsers").document(uid)
            .collection("blocked").document(peerUid).get().await().exists()
        if (iBlocked) return true
        return firestore.collection("blockedUsers").document(peerUid)
            .collection("blocked").document(uid).get().await().exists()
    }

    suspend fun blockUser(peer: UserProfile): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        firestore.collection("blockedUsers").document(uid)
            .collection("blocked").document(peer.uid)
            .set(
                mapOf(
                    "blockedUid" to peer.uid,
                    "ownerUid" to uid,
                    "displayName" to peer.displayName,
                    "username" to peer.username,
                    "photoUrl" to peer.photoUrl,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
    }

    suspend fun unblockUser(blockedUid: String): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        firestore.collection("blockedUsers").document(uid)
            .collection("blocked").document(blockedUid)
            .delete().await()
    }

    suspend fun reportUser(reportedUid: String, reason: String, details: String): Result<Unit> = runCatching {
        val uid = currentUid() ?: error("Not authenticated")
        val reportId = UUID.randomUUID().toString()
        firestore.collection("reports").document(reportId)
            .set(
                mapOf(
                    "reportId" to reportId,
                    "reporterUid" to uid,
                    "reportedUid" to reportedUid,
                    "reason" to reason,
                    "details" to details.trim().take(1000),
                    "status" to "pending",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
    }
}
