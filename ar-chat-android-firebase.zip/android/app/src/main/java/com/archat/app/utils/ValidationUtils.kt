package com.archat.app.utils

import android.util.Patterns

object ValidationUtils {
    private val usernameRegex = Regex("^[a-z0-9_]{3,30}$")

    fun validateDisplayName(name: String): String? {
        val trimmed = name.trim()
        return when {
            trimmed.isEmpty() -> "Full name is required"
            trimmed.length < 2 -> "Full name must be at least 2 characters"
            trimmed.length > 60 -> "Full name must be 60 characters or fewer"
            else -> null
        }
    }

    fun validateUsername(username: String): String? {
        val normalized = username.trim().lowercase()
        return when {
            normalized.isEmpty() -> "Username is required"
            normalized.length < 3 -> "Username must be at least 3 characters"
            normalized.length > 30 -> "Username must be 30 characters or fewer"
            !usernameRegex.matches(normalized) -> "Use only lowercase letters, numbers, and underscores"
            else -> null
        }
    }

    fun validateEmail(email: String): String? {
        val trimmed = email.trim()
        return when {
            trimmed.isEmpty() -> "Email address is required"
            !Patterns.EMAIL_ADDRESS.matcher(trimmed).matches() -> "Enter a valid email address"
            else -> null
        }
    }

    fun validatePassword(password: String): String? {
        return when {
            password.isEmpty() -> "Password is required"
            password.length < 8 -> "Password must be at least 8 characters"
            !password.any { it.isDigit() } -> "Include at least one number"
            !password.any { it.isLetter() } -> "Include at least one letter"
            else -> null
        }
    }

    fun sanitizeMessageText(text: String): String {
        return text.trim().take(4000)
    }
}
