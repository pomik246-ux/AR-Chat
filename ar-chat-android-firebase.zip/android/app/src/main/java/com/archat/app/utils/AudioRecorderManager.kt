package com.archat.app.utils

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

data class RecordingState(
    val isRecording: Boolean = false,
    val elapsedMs: Long = 0L,
    val amplitude: Int = 0,
    val outputFile: File? = null,
    val error: String? = null
)

class AudioRecorderManager(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var startTimeMs: Long = 0L
    private var timerJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _state = MutableStateFlow(RecordingState())
    val state: StateFlow<RecordingState> = _state.asStateFlow()

    fun startRecording() {
        stopInternal(discard = true)
        try {
            val audioDir = File(context.cacheDir, "audio").apply { mkdirs() }
            val file = File(audioDir, "voice_${System.currentTimeMillis()}.m4a")
            currentFile = file

            val mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            mediaRecorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(96_000)
                setAudioSamplingRate(44_100)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }

            recorder = mediaRecorder
            startTimeMs = System.currentTimeMillis()
            _state.value = RecordingState(isRecording = true, elapsedMs = 0L, outputFile = file)

            timerJob = scope.launch {
                while (isActive) {
                    val amp = try {
                        recorder?.maxAmplitude ?: 0
                    } catch (_: Exception) {
                        0
                    }
                    _state.value = _state.value.copy(
                        elapsedMs = System.currentTimeMillis() - startTimeMs,
                        amplitude = amp
                    )
                    delay(100L)
                }
            }
        } catch (e: Exception) {
            _state.value = RecordingState(error = e.localizedMessage ?: "Failed to start recording")
        }
    }

    fun stopAndKeep(): Pair<File, Long>? {
        val file = currentFile
        val duration = (System.currentTimeMillis() - startTimeMs).coerceAtLeast(500L)
        stopInternal(discard = false)
        return if (file != null && file.exists() && file.length() > 0) {
            _state.value = RecordingState(isRecording = false, elapsedMs = duration, outputFile = file)
            file to duration
        } else {
            null
        }
    }

    fun cancelAndDiscard() {
        stopInternal(discard = true)
        _state.value = RecordingState()
    }

    private fun stopInternal(discard: Boolean) {
        timerJob?.cancel()
        timerJob = null
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (_: Exception) {
            recorder?.release()
        } finally {
            recorder = null
        }
        if (discard) {
            currentFile?.delete()
            currentFile = null
        }
    }
}
