package com.archat.app.data.repository

import android.net.Uri
import com.archat.app.data.firebase.PresenceManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

sealed class AuthSessionState {
    data object Loading : AuthSessionState()
    data object Unauthenticated : AuthSessionState()
    data class Unverified(val user: FirebaseUser) : AuthSessionState()
    data class Authenticated(val user: FirebaseUser) : AuthSessionState()
}

class AuthRepository(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
    private val messaging: FirebaseMessaging,
    private val storageRepository: StorageRepository,
    private val presenceManager: PresenceManager
) {
    fun observeAuthState(): Flow<AuthSessionState> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            when {
                user == null -> trySend(AuthSessionState.Unauthenticated)
                !user.isEmailVerified -> trySend(AuthSessionState.Unverified(user))
                else -> {
                    presenceManager.startPresence()
                    trySend(AuthSessionState.Authenticated(user))
                }
            }
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun register(
        fullName: String,
        rawUsername: String,
        email: String,
        password: String,
        photoUri: Uri?
    ): Result<FirebaseUser> = runCatching {
        val cleanName = fullName.trim()
        val username = rawUsername.trim().lowercase()
        val cleanEmail = email.trim()

        // Create Firebase Auth user first (authenticated session needed for Firestore username check)
        val authResult = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
        val user = authResult.user ?: error("Account creation failed")

        try {
            // Atomically verify & reserve unique username
            val usernameRef = firestore.collection("usernames").document(username)
            val userRef = firestore.collection("users").document(user.uid)
            val privateRef = userRef.collection("private").document("info")

            var uploadedPhotoUrl = ""
            if (photoUri != null) {
                uploadedPhotoUrl = storageRepository.uploadProfilePhoto(user.uid, photoUri)
                    .getOrDefault("")
            }

            firestore.runTransaction { tx ->
                val existingUsername = tx.get(usernameRef)
                if (existingUsername.exists()) {
                    throw IllegalStateException("Username @$username is already taken")
                }

                tx.set(
                    usernameRef,
                    mapOf(
                        "uid" to user.uid,
                        "username" to username,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )

                tx.set(
                    userRef,
                    mapOf(
                        "uid" to user.uid,
                        "displayName" to cleanName,
                        "displayNameLower" to cleanName.lowercase(),
                        "username" to username,
                        "usernameLower" to username,
                        "photoUrl" to uploadedPhotoUrl,
                        "bio" to "Hey there! I am using AR Chat.",
                        "isOnline" to false,
                        "privacyShowLastSeen" to "everyone",
                        "privacyShowOnline" to true,
                        "privacyShowPhoto" to "everyone",
                        "privacyWhoCanMessage" to "everyone",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )

                tx.set(
                    privateRef,
                    mapOf(
                        "uid" to user.uid,
                        "email" to cleanEmail,
                        "notifyPrivateMessages" to true,
                        "notifyGroupMessages" to true,
                        "notifyChatInvites" to true,
                        "soundEnabled" to true,
                        "vibrationEnabled" to true,
                        "showMessagePreview" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            val profileUpdate = UserProfileChangeRequest.Builder()
                .setDisplayName(cleanName)
                .apply {
                    if (uploadedPhotoUrl.isNotBlank()) {
                        setPhotoUri(Uri.parse(uploadedPhotoUrl))
                    }
                }
                .build()
            user.updateProfile(profileUpdate).await()
            user.sendEmailVerification().await()
            user
        } catch (e: Exception) {
            // Roll back Auth user if Firestore username reservation failed
            runCatching { user.delete().await() }
            throw e
        }
    }

    suspend fun login(email: String, password: String): Result<FirebaseUser> = runCatching {
        val result = auth.signInWithEmailAndPassword(email.trim(), password).await()
        val user = result.user ?: error("Authentication failed")
        user.reload().await()
        if (user.isEmailVerified) {
            presenceManager.startPresence()
            registerCurrentFcmToken()
        }
        user
    }

    suspend fun resendVerificationEmail(): Result<Unit> = runCatching {
        val user = auth.currentUser ?: error("No active session")
        user.sendEmailVerification().await()
    }

    suspend fun refreshVerificationStatus(): Result<Boolean> = runCatching {
        val user = auth.currentUser ?: error("No active session")
        user.reload().await()
        val verified = user.isEmailVerified
        if (verified) {
            presenceManager.startPresence()
            registerCurrentFcmToken()
        }
        verified
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> = runCatching {
        auth.sendPasswordResetEmail(email.trim()).await()
    }

    suspend fun registerCurrentFcmToken() {
        runCatching {
            val token = messaging.token.await()
            saveFcmToken(token)
        }
    }

    suspend fun saveFcmToken(token: String) {
        val uid = auth.currentUser?.uid ?: return
        if (token.length < 10) return
        val tokenId = sha256Short(token)
        firestore.collection("userDevices")
            .document(uid)
            .collection("tokens")
            .document(tokenId)
            .set(
                mapOf(
                    "tokenId" to tokenId,
                    "uid" to uid,
                    "token" to token,
                    "platform" to "android",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            .await()
    }

    suspend fun logout() {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            runCatching {
                val token = messaging.token.await()
                val tokenId = sha256Short(token)
                firestore.collection("userDevices")
                    .document(uid)
                    .collection("tokens")
                    .document(tokenId)
                    .delete()
                    .await()
            }
        }
        presenceManager.stopPresence()
        auth.signOut()
    }

    private fun sha256Short(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.take(16).joinToString("") { "%02x".format(it) }
    }
}
