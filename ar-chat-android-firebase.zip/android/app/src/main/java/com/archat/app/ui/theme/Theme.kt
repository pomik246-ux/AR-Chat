package com.archat.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = ARGreen,
    onPrimary = Color.White,
    primaryContainer = ARGreenSoft,
    onPrimaryContainer = ARGreenDark,
    secondary = ARGreenDark,
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightCard,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurface,
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder,
    error = DangerRed,
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = ARGreen,
    onPrimary = Color.White,
    primaryContainer = ARGreenDarkSurface,
    onPrimaryContainer = ARGreenSoft,
    secondary = ARGreen,
    onSecondary = Color.White,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkCard,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurface,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder,
    error = DangerRed,
    onError = Color.White
)

@Composable
fun ARChatTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = ARChatTypography,
        content = content
    )
}
