package com.archat.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.PropertyName

enum class MessageType(val value: String) {
    TEXT("text"),
    IMAGE("image"),
    AUDIO("audio");

    companion object {
        fun from(value: String): MessageType =
            entries.firstOrNull { it.value == value } ?: TEXT
    }
}

enum class MessageStatus(val value: String) {
    SENDING("sending"),
    SENT("sent"),
    DELIVERED("delivered"),
    READ("read"),
    FAILED("failed");

    companion object {
        fun from(value: String): MessageStatus =
            entries.firstOrNull { it.value == value } ?: SENT
    }
}

data class PrivateChat(
    val chatId: String = "",
    val participants: List<String> = emptyList(),
    val lastMessageText: String = "",
    val lastMessageType: String = "text",
    val lastMessageSenderId: String = "",
    val lastMessageStatus: String = "sent",
    val lastMessageAt: Timestamp? = null,
    val unreadCounts: Map<String, Long> = emptyMap(),
    val typingUsers: Map<String, Timestamp?> = emptyMap(),
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class ChatMessage(
    val messageId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val senderPhotoUrl: String = "",
    val type: String = "text",
    val text: String = "",
    val mediaUrl: String = "",
    val mediaDurationMs: Long = 0L,
    val replyToMessageId: String = "",
    val replyToText: String = "",
    val replyToSenderName: String = "",
    @get:PropertyName("isForwarded") @set:PropertyName("isForwarded")
    var isForwarded: Boolean = false,
    val status: String = "sent",
    val deliveredTo: List<String> = emptyList(),
    val readBy: List<String> = emptyList(),
    val deletedFor: List<String> = emptyList(),
    @get:PropertyName("isDeletedForEveryone") @set:PropertyName("isDeletedForEveryone")
    var isDeletedForEveryone: Boolean = false,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null,
    // Local-only transient fields for optimistic UI and retry
    val localStatusOverride: String? = null,
    val localError: String? = null,
    val localMediaUri: String? = null
)

data class ChatListItem(
    val chat: PrivateChat,
    val peerProfile: UserProfile?,
    val unreadCount: Int,
    val isPeerTyping: Boolean
)
