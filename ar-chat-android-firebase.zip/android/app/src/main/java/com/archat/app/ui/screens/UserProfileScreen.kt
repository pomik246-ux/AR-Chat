package com.archat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.data.model.UserProfile
import com.archat.app.ui.components.LoadingState
import com.archat.app.ui.components.UserAvatar
import com.archat.app.ui.theme.DangerRed
import com.archat.app.ui.theme.WarningAmber
import com.archat.app.ui.viewmodel.SearchAndProfileViewModel
import com.archat.app.ui.viewmodel.SettingsViewModel
import com.archat.app.utils.DateTimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    uid: String,
    searchViewModel: SearchAndProfileViewModel,
    settingsViewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    onOpenChat: (String) -> Unit
) {
    var userProfile by remember { mutableStateOf<UserProfile?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var showReportDialog by remember { mutableStateOf(false) }
    var reportConfirmed by remember { mutableStateOf(false) }

    val contacts by searchViewModel.contacts.collectAsStateWithLifecycle()
    val blockedUsers by settingsViewModel.blockedUsers.collectAsStateWithLifecycle()

    val existingContact = contacts.firstOrNull { it.contactUid == uid }
    val isBlocked = blockedUsers.any { it.blockedUid == uid }

    LaunchedEffect(uid) {
        FirebaseServiceLocator.userRepository.observeUserProfile(uid).collect {
            userProfile = it
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (isLoading) {
            LoadingState("Loading profile...", Modifier.padding(innerPadding))
        } else {
            val user = userProfile ?: return@Scaffold
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                UserAvatar(
                    photoUrl = if (user.privacyShowPhoto == "nobody") "" else user.photoUrl,
                    displayName = user.displayName,
                    size = 96.dp,
                    isOnline = user.privacyShowOnline && user.isOnline,
                    showOnlineDot = true
                )
                Spacer(Modifier.height(14.dp))
                Text(user.displayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("@${user.username}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(Modifier.height(6.dp))
                val presenceText = when {
                    user.privacyShowOnline && user.isOnline -> "Online"
                    user.privacyShowLastSeen == "everyone" -> DateTimeUtils.formatLastSeen(user.lastSeen)
                    else -> "Status hidden"
                }
                Text(presenceText, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)

                Spacer(Modifier.height(16.dp))
                Text(
                    text = user.bio.ifBlank { "Hey there! I am using AR Chat." },
                    style = MaterialTheme.typography.bodyLarge
                )

                Spacer(Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { searchViewModel.startPrivateChat(uid, onOpenChat) },
                        enabled = !isBlocked,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Chat, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Message")
                    }

                    OutlinedButton(
                        onClick = {
                            if (existingContact == null) {
                                searchViewModel.addContact(user, favorite = false)
                            } else {
                                searchViewModel.toggleFavorite(uid, !existingContact.isFavorite)
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = when {
                                existingContact == null -> Icons.Filled.PersonAdd
                                existingContact.isFavorite -> Icons.Filled.Star
                                else -> Icons.Filled.StarBorder
                            },
                            contentDescription = null,
                            tint = if (existingContact?.isFavorite == true) WarningAmber else MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            when {
                                existingContact == null -> "Add Contact"
                                existingContact.isFavorite -> "Favorited"
                                else -> "Favorite"
                            }
                        )
                    }
                }

                Spacer(Modifier.height(24.dp))
                HorizontalDivider()
                Spacer(Modifier.height(16.dp))

                OutlinedButton(
                    onClick = {
                        if (isBlocked) searchViewModel.unblockUser(uid)
                        else searchViewModel.blockUser(user)
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Block, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isBlocked) "Unblock ${user.displayName}" else "Block ${user.displayName}")
                }

                Spacer(Modifier.height(10.dp))

                TextButton(
                    onClick = { showReportDialog = true },
                    colors = ButtonDefaults.textButtonColors(contentColor = DangerRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Flag, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Report User")
                }

                if (reportConfirmed) {
                    Spacer(Modifier.height(8.dp))
                    Text("Report submitted. Thank you for keeping AR Chat safe.", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }

    if (showReportDialog) {
        var selectedReason by remember { mutableStateOf("spam") }
        var details by remember { mutableStateOf("") }
        val reasons = listOf(
            "spam" to "Spam or unwanted messages",
            "harassment" to "Harassment or abuse",
            "impersonation" to "Impersonation",
            "inappropriate_content" to "Inappropriate content",
            "other" to "Other"
        )
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Report User") },
            text = {
                Column {
                    reasons.forEach { (key, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selectedReason == key, onClick = { selectedReason = key })
                            Text(label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = details,
                        onValueChange = { details = it },
                        label = { Text("Additional details (optional)") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        searchViewModel.reportUser(uid, selectedReason, details) {
                            showReportDialog = false
                            reportConfirmed = true
                        }
                    }
                ) { Text("Submit Report") }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) { Text("Cancel") }
            }
        )
    }
}
