package com.archat.app.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.data.model.ChatMessage
import com.archat.app.ui.components.ChatInputBar
import com.archat.app.ui.components.EmptyState
import com.archat.app.ui.components.MessageBubble
import com.archat.app.ui.components.UserAvatar
import com.archat.app.ui.theme.ARGreen
import com.archat.app.ui.viewmodel.PrivateChatViewModel
import com.archat.app.ui.viewmodel.SearchAndProfileViewModel
import com.archat.app.utils.DateTimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivateChatScreen(
    chatId: String,
    searchViewModel: SearchAndProfileViewModel,
    onNavigateBack: () -> Unit,
    onOpenProfile: (String) -> Unit,
    onOpenImageViewer: (String) -> Unit,
    viewModel: PrivateChatViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val recordingState by viewModel.recordingState.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val searchUsers by searchViewModel.searchResults.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var forwardTargetMessage by remember { mutableStateOf<ChatMessage?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    val myUid = FirebaseServiceLocator.auth.currentUser?.uid ?: ""

    LaunchedEffect(chatId) {
        viewModel.loadChat(chatId)
    }

    val allMessages = remember(uiState.olderMessages, uiState.messages, uiState.failedMessages) {
        (uiState.olderMessages + uiState.messages + uiState.failedMessages).distinctBy { it.messageId }
    }

    LaunchedEffect(allMessages.size) {
        if (allMessages.isNotEmpty()) {
            listState.animateScrollToItem(allMessages.lastIndex)
        }
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.sendImageMessage(uri)
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.startRecording()
    }

    val peer = uiState.peerProfile
    val typingTs = uiState.chat?.typingUsers?.get(uiState.peerUid)
    val isPeerTyping = typingTs != null && (System.currentTimeMillis() - typingTs.toDate().time) < 6000L

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (uiState.peerUid.isNotBlank()) onOpenProfile(uiState.peerUid)
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(
                            photoUrl = peer?.photoUrl ?: "",
                            displayName = peer?.displayName ?: "AR Chat",
                            size = 38.dp,
                            isOnline = peer?.privacyShowOnline == true && peer.isOnline,
                            showOnlineDot = true
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = peer?.displayName ?: "Chat",
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val subtitle = when {
                                isPeerTyping -> "typing..."
                                peer?.privacyShowOnline == true && peer.isOnline -> "Online"
                                peer?.privacyShowLastSeen == "everyone" -> DateTimeUtils.formatLastSeen(peer.lastSeen)
                                else -> "@${peer?.username ?: ""}"
                            }
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isPeerTyping) ARGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (uiState.isBlocked) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "You cannot message this user because one of you has blocked the other.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            } else {
                ChatInputBar(
                    text = inputText,
                    onTextChange = {
                        inputText = it
                        viewModel.onTypingChanged(it)
                    },
                    replyingTo = uiState.replyingTo,
                    onCancelReply = { viewModel.setReplyTarget(null) },
                    recordingState = recordingState,
                    previewAudio = uiState.previewAudio,
                    onPickImage = { imagePicker.launch("image/*") },
                    onStartRecording = {
                        val granted = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) viewModel.startRecording()
                        else audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onStopRecording = { viewModel.stopRecordingForPreview() },
                    onDiscardRecording = { viewModel.discardRecording() },
                    onSendText = {
                        val msg = inputText
                        inputText = ""
                        viewModel.onTypingChanged("")
                        viewModel.sendTextMessage(msg)
                    },
                    onSendVoicePreview = { viewModel.sendVoicePreview() }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (allMessages.isEmpty()) {
                EmptyState(
                    icon = Icons.Outlined.Lock,
                    title = "Say hello to ${peer?.displayName ?: "your contact"}",
                    subtitle = "Messages sent here sync in real time with Firebase."
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (uiState.hasMoreOlder && allMessages.size >= 30) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                TextButton(
                                    onClick = { viewModel.loadOlderMessages() },
                                    enabled = !uiState.isLoadingMore
                                ) {
                                    Text(if (uiState.isLoadingMore) "Loading older..." else "Load older messages")
                                }
                            }
                        }
                    }

                    items(allMessages, key = { it.messageId }) { msg ->
                        MessageBubble(
                            message = msg,
                            isOutgoing = msg.senderId == myUid,
                            showSenderName = false,
                            playbackState = playbackState,
                            uploadFraction = uiState.uploadProgress[msg.messageId],
                            onImageClick = onOpenImageViewer,
                            onToggleVoicePlay = { viewModel.togglePlayVoice(msg) },
                            onSeekVoice = { pos -> viewModel.seekVoice(msg.messageId, pos) },
                            onReply = { viewModel.setReplyTarget(msg) },
                            onForward = { forwardTargetMessage = msg },
                            onCopy = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("AR Chat", msg.text))
                            },
                            onDeleteForMe = { viewModel.deleteForMe(msg.messageId) },
                            onDeleteForEveryone = { viewModel.deleteForEveryone(msg.messageId) },
                            onRetry = { viewModel.retryFailedMessage(msg) }
                        )
                    }
                }
            }
        }
    }

    forwardTargetMessage?.let { msgToForward ->
        ModalBottomSheet(onDismissRequest = { forwardTargetMessage = null }) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Forward message to...", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                LazyColumn {
                    items(searchUsers, key = { it.uid }) { targetUser ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.forwardMessageToChat(targetUser.uid, msgToForward) {
                                        forwardTargetMessage = null
                                    }
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatar(photoUrl = targetUser.photoUrl, displayName = targetUser.displayName, size = 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(targetUser.displayName, fontWeight = FontWeight.SemiBold)
                                Text("@${targetUser.username}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
