package com.archat.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.archat.app.utils.AudioPlaybackState
import com.archat.app.utils.DateTimeUtils

@Composable
fun VoiceMessagePlayback(
    messageId: String,
    mediaUrl: String,
    durationMs: Long,
    playbackState: AudioPlaybackState,
    isOutgoing: Boolean,
    onTogglePlay: () -> Unit,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val isActive = playbackState.activeMessageId == messageId
    val isPlaying = isActive && playbackState.isPlaying
    val isLoading = isActive && playbackState.isLoading
    val totalMs = if (isActive && playbackState.durationMs > 0L) playbackState.durationMs else durationMs.coerceAtLeast(1000L)
    val currentMs = if (isActive) playbackState.currentPositionMs.coerceIn(0L, totalMs) else 0L

    val fgColor = if (isOutgoing) Color.White else MaterialTheme.colorScheme.onSurface
    val subColor = if (isOutgoing) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        modifier = modifier.width(220.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onTogglePlay,
            enabled = mediaUrl.isNotBlank() && !isLoading,
            modifier = Modifier.size(40.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = fgColor
                )
            } else {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Pause voice message" else "Play voice message",
                    tint = fgColor
                )
            }
        }

        Spacer(Modifier.width(4.dp))

        Column(modifier = Modifier.weight(1f)) {
            Slider(
                value = if (totalMs > 0L) currentMs.toFloat() / totalMs.toFloat() else 0f,
                onValueChange = { fraction ->
                    if (isActive) {
                        onSeek((fraction * totalMs).toLong())
                    }
                },
                colors = SliderDefaults.colors(
                    thumbColor = fgColor,
                    activeTrackColor = fgColor,
                    inactiveTrackColor = fgColor.copy(alpha = 0.3f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(24.dp)
            )
            Text(
                text = if (isActive && currentMs > 0L) {
                    "${DateTimeUtils.formatDuration(currentMs)} / ${DateTimeUtils.formatDuration(totalMs)}"
                } else {
                    DateTimeUtils.formatDuration(totalMs)
                },
                style = MaterialTheme.typography.labelSmall,
                color = subColor
            )
        }
    }
}
