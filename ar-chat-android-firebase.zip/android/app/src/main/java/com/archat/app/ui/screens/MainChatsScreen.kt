package com.archat.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.ui.components.ARLogo
import com.archat.app.ui.components.EmptyState
import com.archat.app.ui.components.OfflineBanner
import com.archat.app.ui.components.UserAvatar
import com.archat.app.ui.theme.ARGreen
import com.archat.app.ui.theme.TickReadColor
import com.archat.app.ui.viewmodel.ConversationItem
import com.archat.app.ui.viewmodel.HomeViewModel
import com.archat.app.ui.viewmodel.SearchAndProfileViewModel
import com.archat.app.ui.viewmodel.SettingsViewModel
import com.archat.app.utils.DateTimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainChatsScreen(
    homeViewModel: HomeViewModel,
    searchViewModel: SearchAndProfileViewModel,
    settingsViewModel: SettingsViewModel,
    onOpenPrivateChat: (String) -> Unit,
    onOpenGroupChat: (String) -> Unit,
    onOpenNewChat: () -> Unit,
    onOpenCreateGroup: () -> Unit,
    onOpenUserProfile: (String) -> Unit,
    onOpenEditProfile: () -> Unit,
    onOpenPrivacySettings: () -> Unit,
    onOpenBlockedUsers: () -> Unit,
    onOpenNotificationSettings: () -> Unit
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val conversations by homeViewModel.conversations.collectAsStateWithLifecycle()
    val searchQuery by homeViewModel.searchQuery.collectAsStateWithLifecycle()
    val isOffline by homeViewModel.isOffline.collectAsStateWithLifecycle()
    val myUid = FirebaseServiceLocator.auth.currentUser?.uid ?: ""

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ARLogo(size = 30.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = when (selectedTab) {
                                0 -> "AR Chat"
                                1 -> "People"
                                else -> "Settings"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                actions = {
                    if (selectedTab == 0) {
                        IconButton(onClick = onOpenCreateGroup) {
                            Icon(Icons.Filled.GroupAdd, contentDescription = "Create group")
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Filled.Chat, contentDescription = null) },
                    label = { Text("Chats") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Filled.People, contentDescription = null) },
                    label = { Text("People") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("Settings") }
                )
            }
        },
        floatingActionButton = {
            if (selectedTab == 0) {
                FloatingActionButton(
                    onClick = onOpenNewChat,
                    containerColor = ARGreen,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Filled.Chat, contentDescription = "New Chat")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            OfflineBanner(isOffline = isOffline)

            when (selectedTab) {
                0 -> {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { homeViewModel.updateSearchQuery(it) },
                        placeholder = { Text("Search chats or people") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )

                    if (conversations.isEmpty()) {
                        EmptyState(
                            icon = Icons.Outlined.ChatBubbleOutline,
                            title = if (searchQuery.isBlank()) "No conversations yet" else "No matching chats",
                            subtitle = if (searchQuery.isBlank()) {
                                "Start a private conversation or create a group with your contacts."
                            } else {
                                "Try a different name or username."
                            },
                            actionLabel = if (searchQuery.isBlank()) "Start a Chat" else null,
                            onAction = if (searchQuery.isBlank()) onOpenNewChat else null
                        )
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(
                                items = conversations,
                                key = {
                                    when (it) {
                                        is ConversationItem.PrivateItem -> "p_${it.chat.chatId}"
                                        is ConversationItem.GroupItem -> "g_${it.group.groupId}"
                                    }
                                }
                            ) { item ->
                                when (item) {
                                    is ConversationItem.PrivateItem -> {
                                        val peer = item.peer
                                        val showOnline = peer?.privacyShowOnline == true && peer.isOnline
                                        ConversationRow(
                                            title = peer?.displayName ?: "AR Chat User",
                                            photoUrl = peer?.photoUrl ?: "",
                                            subtitle = if (item.isPeerTyping) {
                                                "typing..."
                                            } else {
                                                item.chat.lastMessageText.ifBlank { "Tap to start chatting" }
                                            },
                                            isTyping = item.isPeerTyping,
                                            timeLabel = DateTimeUtils.formatChatListTime(item.chat.lastMessageAt),
                                            unreadCount = item.unreadCount,
                                            isOnline = showOnline,
                                            showOnlineDot = true,
                                            lastMessageStatus = if (item.chat.lastMessageSenderId == myUid) {
                                                item.chat.lastMessageStatus
                                            } else null,
                                            onClick = { onOpenPrivateChat(item.chat.chatId) }
                                        )
                                    }
                                    is ConversationItem.GroupItem -> {
                                        ConversationRow(
                                            title = item.group.name,
                                            photoUrl = item.group.photoUrl,
                                            subtitle = item.group.lastMessageText.ifBlank { "${item.group.memberIds.size} members" },
                                            isTyping = false,
                                            timeLabel = DateTimeUtils.formatChatListTime(item.group.lastMessageAt),
                                            unreadCount = item.unreadCount,
                                            isOnline = false,
                                            showOnlineDot = false,
                                            lastMessageStatus = null,
                                            onClick = { onOpenGroupChat(item.group.groupId) }
                                        )
                                    }
                                }
                                HorizontalDivider(
                                    modifier = Modifier.padding(start = 78.dp),
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                                )
                            }
                        }
                    }
                }
                1 -> {
                    SearchUsersContent(
                        searchViewModel = searchViewModel,
                        onUserClick = onOpenUserProfile,
                        onStartChat = { peerUid ->
                            searchViewModel.startPrivateChat(peerUid, onOpenPrivateChat)
                        }
                    )
                }
                else -> {
                    SettingsContent(
                        settingsViewModel = settingsViewModel,
                        onEditProfile = onOpenEditProfile,
                        onPrivacySettings = onOpenPrivacySettings,
                        onBlockedUsers = onOpenBlockedUsers,
                        onNotificationSettings = onOpenNotificationSettings
                    )
                }
            }
        }
    }
}

@Composable
private fun ConversationRow(
    title: String,
    photoUrl: String,
    subtitle: String,
    isTyping: Boolean,
    timeLabel: String,
    unreadCount: Int,
    isOnline: Boolean,
    showOnlineDot: Boolean,
    lastMessageStatus: String?,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        UserAvatar(
            photoUrl = photoUrl,
            displayName = title,
            size = 50.dp,
            isOnline = isOnline,
            showOnlineDot = showOnlineDot
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = timeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (unreadCount > 0) ARGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (lastMessageStatus != null && !isTyping) {
                    when (lastMessageStatus) {
                        "sent" -> Icon(
                            Icons.Filled.Done,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        "delivered" -> Icon(
                            Icons.Filled.DoneAll,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        "read" -> Icon(
                            Icons.Filled.DoneAll,
                            contentDescription = null,
                            tint = TickReadColor,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isTyping) ARGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (unreadCount > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ARGreen)
                            .padding(horizontal = 7.dp, vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (unreadCount > 99) "99+" else unreadCount.toString(),
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
