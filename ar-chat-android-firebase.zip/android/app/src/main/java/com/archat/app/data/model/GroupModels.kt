package com.archat.app.data.model

import com.google.firebase.Timestamp

data class GroupChat(
    val groupId: String = "",
    val name: String = "",
    val description: String = "",
    val photoUrl: String = "",
    val createdBy: String = "",
    val memberIds: List<String> = emptyList(),
    val adminIds: List<String> = emptyList(),
    val lastMessageText: String = "",
    val lastMessageType: String = "system",
    val lastMessageSenderId: String = "",
    val lastMessageAt: Timestamp? = null,
    val unreadCounts: Map<String, Long> = emptyMap(),
    val typingUsers: Map<String, Timestamp?> = emptyMap(),
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class GroupMember(
    val uid: String = "",
    val groupId: String = "",
    val role: String = "member", // admin | member
    val displayName: String = "",
    val username: String = "",
    val photoUrl: String = "",
    val muted: Boolean = false,
    val joinedAt: Timestamp? = null
)
