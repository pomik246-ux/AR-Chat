package com.archat.app.data.repository

import com.archat.app.data.model.ChatMessage
import com.archat.app.data.model.PrivateChat
import com.archat.app.data.model.UserProfile
import com.archat.app.utils.ChatIdUtils
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ChatRepository(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
    private val storageRepository: StorageRepository
) {
    fun currentUid(): String? = auth.currentUser?.uid

    fun observeMyPrivateChats(): Flow<List<PrivateChat>> = callbackFlow {
        val uid = currentUid() ?: run {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val reg = firestore.collection("chats")
            .whereArrayContains("participants", uid)
            .orderBy("lastMessageAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap?.toObjects(PrivateChat::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeChat(chatId: String): Flow<PrivateChat?> = callbackFlow {
        val reg = firestore.collection("chats").document(chatId)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObject(PrivateChat::class.java))
            }
        awaitClose { reg.remove() }
    }

    suspend fun getOrCreatePrivateChat(peerUid: String): Result<String> = runCatching {
        val myUid = currentUid() ?: error("Not authenticated")
        val chatId = ChatIdUtils.deterministicChatId(myUid, peerUid)
        val chatRef = firestore.collection("chats").document(chatId)
        val snap = chatRef.get().await()
        if (!snap.exists()) {
            val sortedParticipants = if (myUid < peerUid) listOf(myUid, peerUid) else listOf(peerUid, myUid)
            chatRef.set(
                mapOf(
                    "chatId" to chatId,
                    "participants" to sortedParticipants,
                    "lastMessageText" to "",
                    "lastMessageType" to "text",
                    "lastMessageSenderId" to "",
                    "lastMessageStatus" to "sent",
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "unreadCounts" to mapOf(myUid to 0L, peerUid to 0L),
                    "typingUsers" to emptyMap<String, Any>(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        chatId
    }

    fun observeRecentMessages(chatId: String, pageSize: Long = 35L): Flow<Pair<List<ChatMessage>, DocumentSnapshot?>> = callbackFlow {
        val reg = firestore.collection("chats").document(chatId)
            .collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(pageSize)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    trySend(emptyList<ChatMessage>() to null)
                    return@addSnapshotListener
                }
                val docs = snap?.documents ?: emptyList()
                val messages = docs.mapNotNull { it.toObject(ChatMessage::class.java) }.reversed()
                val oldestDoc = docs.lastOrNull()
                trySend(messages to oldestDoc)
            }
        awaitClose { reg.remove() }
    }

    suspend fun loadOlderMessages(
        chatId: String,
        oldestSnapshot: DocumentSnapshot,
        pageSize: Long = 30L
    ): Result<Pair<List<ChatMessage>, DocumentSnapshot?>> = runCatching {
        val snap = firestore.collection("chats").document(chatId)
            .collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .startAfter(oldestSnapshot)
            .limit(pageSize)
            .get()
            .await()
        val docs = snap.documents
        val messages = docs.mapNotNull { it.toObject(ChatMessage::class.java) }.reversed()
        messages to docs.lastOrNull()
    }

    suspend fun sendMessage(
        chatId: String,
        peerUid: String,
        senderProfile: UserProfile,
        type: String,
        text: String,
        mediaUrl: String = "",
        mediaDurationMs: Long = 0L,
        replyTo: ChatMessage? = null,
        isForwarded: Boolean = false,
        customMessageId: String = UUID.randomUUID().toString()
    ): Result<String> = runCatching {
        val myUid = currentUid() ?: error("Not authenticated")
        val chatRef = firestore.collection("chats").document(chatId)
        val msgRef = chatRef.collection("messages").document(customMessageId)

        val previewText = when (type) {
            "image" -> if (text.isNotBlank()) "📷 $text" else "📷 Photo"
            "audio" -> "🎙️ Voice message"
            else -> text.take(500)
        }

        val messagePayload = mutableMapOf<String, Any>(
            "messageId" to customMessageId,
            "senderId" to myUid,
            "senderName" to senderProfile.displayName.ifBlank { senderProfile.username },
            "senderPhotoUrl" to senderProfile.photoUrl,
            "type" to type,
            "text" to text.take(4000),
            "isForwarded" to isForwarded,
            "status" to "sent",
            "deliveredTo" to emptyList<String>(),
            "readBy" to emptyList<String>(),
            "deletedFor" to emptyList<String>(),
            "isDeletedForEveryone" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        if (mediaUrl.isNotBlank()) {
            messagePayload["mediaUrl"] = mediaUrl
        }
        if (mediaDurationMs > 0L) {
            messagePayload["mediaDurationMs"] = mediaDurationMs
        }
        if (replyTo != null) {
            messagePayload["replyToMessageId"] = replyTo.messageId
            messagePayload["replyToText"] = when {
                replyTo.isDeletedForEveryone -> "Deleted message"
                replyTo.type == "image" -> "📷 Photo"
                replyTo.type == "audio" -> "🎙️ Voice message"
                else -> replyTo.text.take(300)
            }
            messagePayload["replyToSenderName"] = replyTo.senderName
        }

        firestore.runTransaction { tx ->
            val chatSnap = tx.get(chatRef)
            val currentUnread = (chatSnap.get("unreadCounts.$peerUid") as? Long) ?: 0L
            tx.set(msgRef, messagePayload)
            tx.update(
                chatRef,
                mapOf(
                    "lastMessageText" to previewText,
                    "lastMessageType" to type,
                    "lastMessageSenderId" to myUid,
                    "lastMessageStatus" to "sent",
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "unreadCounts.$peerUid" to (currentUnread + 1L),
                    "typingUsers.$myUid" to FieldValue.delete(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()

        customMessageId
    }

    suspend fun markMessagesDeliveredAndRead(chatId: String, messages: List<ChatMessage>) {
        val myUid = currentUid() ?: return
        val incomingToMark = messages.filter {
            it.senderId != myUid && (it.status != "read" || !it.readBy.contains(myUid))
        }
        if (incomingToMark.isEmpty()) return

        runCatching {
            val batch = firestore.batch()
            val chatRef = firestore.collection("chats").document(chatId)
            incomingToMark.take(40).forEach { msg ->
                val msgRef = chatRef.collection("messages").document(msg.messageId)
                batch.update(
                    msgRef,
                    mapOf(
                        "status" to "read",
                        "deliveredTo" to FieldValue.arrayUnion(myUid),
                        "readBy" to FieldValue.arrayUnion(myUid),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.update(
                chatRef,
                mapOf(
                    "lastMessageStatus" to "read",
                    "unreadCounts.$myUid" to 0L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
        }
    }

    suspend fun markIncomingChatsDelivered(chats: List<PrivateChat>) {
        val myUid = currentUid() ?: return
        chats.filter { it.lastMessageSenderId != myUid && it.lastMessageStatus == "sent" }
            .forEach { chat ->
                runCatching {
                    firestore.collection("chats").document(chat.chatId)
                        .update(
                            mapOf(
                                "lastMessageStatus" to "delivered",
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                }
            }
    }

    suspend fun setTypingStatus(chatId: String, isTyping: Boolean) {
        val myUid = currentUid() ?: return
        runCatching {
            val value: Any = if (isTyping) Timestamp.now() else FieldValue.delete()
            firestore.collection("chats").document(chatId)
                .update(
                    mapOf(
                        "typingUsers.$myUid" to value,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        }
    }

    suspend fun deleteMessageForEveryone(chatId: String, messageId: String): Result<Unit> = runCatching {
        firestore.collection("chats").document(chatId)
            .collection("messages").document(messageId)
            .update(
                mapOf(
                    "isDeletedForEveryone" to true,
                    "text" to "This message was deleted",
                    "mediaUrl" to "",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
    }

    suspend fun deleteMessageForMe(chatId: String, messageId: String): Result<Unit> = runCatching {
        val myUid = currentUid() ?: error("Not authenticated")
        firestore.collection("chats").document(chatId)
            .collection("messages").document(messageId)
            .update(
                mapOf(
                    "deletedFor" to FieldValue.arrayUnion(myUid),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
    }
}
