package com.archat.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.PersonSearch
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.archat.app.ui.components.EmptyState
import com.archat.app.ui.components.LoadingState
import com.archat.app.ui.components.UserAvatar
import com.archat.app.ui.theme.ARGreen
import com.archat.app.ui.theme.WarningAmber
import com.archat.app.ui.viewmodel.SearchAndProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchUsersScreen(
    searchViewModel: SearchAndProfileViewModel,
    onNavigateBack: () -> Unit,
    onOpenUserProfile: (String) -> Unit,
    onOpenChat: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Search People") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            SearchUsersContent(
                searchViewModel = searchViewModel,
                onUserClick = onOpenUserProfile,
                onStartChat = { uid -> searchViewModel.startPrivateChat(uid, onOpenChat) }
            )
        }
    }
}

@Composable
fun SearchUsersContent(
    searchViewModel: SearchAndProfileViewModel,
    onUserClick: (String) -> Unit,
    onStartChat: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val results by searchViewModel.searchResults.collectAsStateWithLifecycle()
    val contacts by searchViewModel.contacts.collectAsStateWithLifecycle()
    val isSearching by searchViewModel.isSearching.collectAsStateWithLifecycle()
    val error by searchViewModel.error.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = {
                query = it
                searchViewModel.searchUsers(it)
            },
            placeholder = { Text("Search by @username or name") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )

        error?.let {
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        if (isSearching && results.isEmpty()) {
            LoadingState("Searching AR Chat directory...")
        } else if (results.isEmpty() && contacts.isEmpty()) {
            EmptyState(
                icon = Icons.Outlined.PersonSearch,
                title = "No users found",
                subtitle = "Try searching with a different username or display name."
            )
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                if (query.isBlank() && contacts.isNotEmpty()) {
                    item {
                        Text(
                            text = "Contacts & Favorites",
                            style = MaterialTheme.typography.labelLarge,
                            color = ARGreen,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                    items(contacts, key = { "c_${it.contactUid}" }) { contact ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onUserClick(contact.contactUid) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatar(photoUrl = contact.photoUrl, displayName = contact.displayName, size = 46.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(contact.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("@${contact.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (contact.isFavorite) {
                                Icon(Icons.Filled.Star, contentDescription = "Favorite", tint = WarningAmber)
                            }
                            IconButton(onClick = { onStartChat(contact.contactUid) }) {
                                Icon(Icons.Filled.Chat, contentDescription = "Message", tint = ARGreen)
                            }
                        }
                        HorizontalDivider(modifier = Modifier.padding(start = 74.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                    }
                }

                item {
                    Text(
                        text = if (query.isBlank()) "Discover People" else "Search Results",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }

                items(results, key = { "u_${it.uid}" }) { user ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onUserClick(user.uid) }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(
                            photoUrl = if (user.privacyShowPhoto == "nobody") "" else user.photoUrl,
                            displayName = user.displayName,
                            size = 46.dp,
                            isOnline = user.privacyShowOnline && user.isOnline,
                            showOnlineDot = true
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(user.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                text = "@${user.username} · ${user.bio}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { onStartChat(user.uid) }) {
                            Icon(Icons.Filled.Chat, contentDescription = "Chat", tint = ARGreen)
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(start = 74.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                }
            }
        }
    }
}
