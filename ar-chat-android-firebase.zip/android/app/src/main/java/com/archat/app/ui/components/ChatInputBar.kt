package com.archat.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archat.app.data.model.ChatMessage
import com.archat.app.ui.theme.ARGreen
import com.archat.app.ui.theme.DangerRed
import com.archat.app.utils.DateTimeUtils
import com.archat.app.utils.RecordingState
import java.io.File

private val quickEmojis = listOf("😀", "😂", "❤️", "👍", "🙏", "🔥", "🎉", "😮", "😢", "👏", "💯", "✨")

@Composable
fun ChatInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    replyingTo: ChatMessage?,
    onCancelReply: () -> Unit,
    recordingState: RecordingState,
    previewAudio: Pair<File, Long>?,
    onPickImage: () -> Unit,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onDiscardRecording: () -> Unit,
    onSendText: () -> Unit,
    onSendVoicePreview: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showEmojiBar by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier.fillMaxWidth(),
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            AnimatedVisibility(visible = replyingTo != null) {
                replyingTo?.let { reply ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Replying to ${reply.senderName}",
                                style = MaterialTheme.typography.labelMedium,
                                color = ARGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = when (reply.type) {
                                    "image" -> "📷 Photo"
                                    "audio" -> "🎙️ Voice message"
                                    else -> reply.text
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = onCancelReply, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Close, contentDescription = "Cancel reply", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            AnimatedVisibility(visible = showEmojiBar) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(quickEmojis) { emoji ->
                        Text(
                            text = emoji,
                            fontSize = 24.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable { onTextChange(text + emoji) }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            when {
                recordingState.isRecording -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(DangerRed.copy(alpha = 0.1f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onDiscardRecording) {
                            Icon(Icons.Filled.Delete, contentDescription = "Cancel recording", tint = DangerRed)
                        }
                        Text(
                            text = "Recording ${DateTimeUtils.formatDuration(recordingState.elapsedMs)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = DangerRed,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = onStopRecording,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(ARGreen)
                        ) {
                            Icon(Icons.Filled.Stop, contentDescription = "Stop recording", tint = Color.White)
                        }
                    }
                }
                previewAudio != null -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onDiscardRecording) {
                            Icon(Icons.Filled.Delete, contentDescription = "Discard voice note", tint = DangerRed)
                        }
                        Text(
                            text = "Voice note ready (${DateTimeUtils.formatDuration(previewAudio.second)})",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = onSendVoicePreview,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(ARGreen)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send voice note", tint = Color.White)
                        }
                    }
                }
                else -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { showEmojiBar = !showEmojiBar }) {
                                Icon(
                                    imageVector = Icons.Filled.Mood,
                                    contentDescription = "Emoji",
                                    tint = if (showEmojiBar) ARGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextField(
                                value = text,
                                onValueChange = onTextChange,
                                placeholder = { Text("Message") },
                                maxLines = 4,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = onPickImage) {
                                Icon(
                                    imageVector = Icons.Filled.Image,
                                    contentDescription = "Attach image",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(Modifier.width(8.dp))

                        val hasText = text.isNotBlank()
                        IconButton(
                            onClick = { if (hasText) onSendText() else onStartRecording() },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(ARGreen)
                        ) {
                            Icon(
                                imageVector = if (hasText) Icons.AutoMirrored.Filled.Send else Icons.Filled.Mic,
                                contentDescription = if (hasText) "Send message" else "Record voice note",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
