package com.archat.app.data.firebase

import android.content.Context
import com.archat.app.BuildConfig
import com.archat.app.data.repository.AuthRepository
import com.archat.app.data.repository.ChatRepository
import com.archat.app.data.repository.GroupRepository
import com.archat.app.data.repository.StorageRepository
import com.archat.app.data.repository.UserRepository
import com.archat.app.utils.AudioPlayerManager
import com.archat.app.utils.AudioRecorderManager
import com.archat.app.utils.NetworkMonitor
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage

object FirebaseServiceLocator {
    private lateinit var appContext: Context

    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    val firestore: FirebaseFirestore by lazy {
        val db = if (BuildConfig.FIRESTORE_DATABASE_ID.isNotBlank()) {
            FirebaseFirestore.getInstance(FirebaseApp.getInstance(), BuildConfig.FIRESTORE_DATABASE_ID)
        } else {
            FirebaseFirestore.getInstance()
        }
        db.firestoreSettings = FirebaseFirestoreSettings.Builder()
            .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
            .build()
        db
    }

    val storage: FirebaseStorage by lazy { FirebaseStorage.getInstance() }
    val messaging: FirebaseMessaging by lazy { FirebaseMessaging.getInstance() }
    val realtimeDb: FirebaseDatabase? by lazy {
        try {
            FirebaseDatabase.getInstance()
        } catch (_: Exception) {
            null
        }
    }

    val networkMonitor: NetworkMonitor by lazy { NetworkMonitor(appContext) }
    val audioRecorder: AudioRecorderManager by lazy { AudioRecorderManager(appContext) }
    val audioPlayer: AudioPlayerManager by lazy { AudioPlayerManager() }
    val presenceManager: PresenceManager by lazy { PresenceManager(auth, firestore, realtimeDb) }

    val storageRepository: StorageRepository by lazy { StorageRepository(storage, appContext) }
    val userRepository: UserRepository by lazy { UserRepository(auth, firestore, storageRepository) }
    val authRepository: AuthRepository by lazy {
        AuthRepository(auth, firestore, messaging, storageRepository, presenceManager)
    }
    val chatRepository: ChatRepository by lazy {
        ChatRepository(auth, firestore, storageRepository)
    }
    val groupRepository: GroupRepository by lazy {
        GroupRepository(auth, firestore, storageRepository)
    }

    fun initialize(context: Context) {
        appContext = context.applicationContext
    }
}
