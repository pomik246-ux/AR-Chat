package com.archat.app.utils

import android.media.AudioAttributes
import android.media.MediaPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class AudioPlaybackState(
    val activeMessageId: String? = null,
    val isPlaying: Boolean = false,
    val isLoading: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val error: String? = null
)

class AudioPlayerManager {
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _playbackState = MutableStateFlow(AudioPlaybackState())
    val playbackState: StateFlow<AudioPlaybackState> = _playbackState.asStateFlow()

    fun togglePlay(messageId: String, audioSource: String, fallbackDurationMs: Long = 0L) {
        val current = _playbackState.value
        if (current.activeMessageId == messageId && mediaPlayer != null) {
            if (current.isPlaying) {
                mediaPlayer?.pause()
                progressJob?.cancel()
                _playbackState.value = current.copy(isPlaying = false)
            } else {
                mediaPlayer?.start()
                startProgressLoop()
                _playbackState.value = current.copy(isPlaying = true)
            }
            return
        }

        stop()
        _playbackState.value = AudioPlaybackState(
            activeMessageId = messageId,
            isLoading = true,
            durationMs = fallbackDurationMs
        )

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(audioSource)
                setOnPreparedListener { mp ->
                    mp.start()
                    _playbackState.value = AudioPlaybackState(
                        activeMessageId = messageId,
                        isPlaying = true,
                        isLoading = false,
                        currentPositionMs = 0L,
                        durationMs = mp.duration.toLong().coerceAtLeast(fallbackDurationMs)
                    )
                    startProgressLoop()
                }
                setOnCompletionListener {
                    progressJob?.cancel()
                    _playbackState.value = AudioPlaybackState(
                        activeMessageId = messageId,
                        isPlaying = false,
                        currentPositionMs = 0L,
                        durationMs = duration.toLong().coerceAtLeast(fallbackDurationMs)
                    )
                }
                setOnErrorListener { _, _, _ ->
                    stop()
                    _playbackState.value = AudioPlaybackState(
                        activeMessageId = messageId,
                        error = "Unable to play voice message"
                    )
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            stop()
            _playbackState.value = AudioPlaybackState(
                activeMessageId = messageId,
                error = e.localizedMessage ?: "Audio playback failed"
            )
        }
    }

    fun seekTo(messageId: String, positionMs: Long) {
        if (_playbackState.value.activeMessageId != messageId) return
        mediaPlayer?.seekTo(positionMs.toInt())
        _playbackState.value = _playbackState.value.copy(currentPositionMs = positionMs)
    }

    fun stop() {
        progressJob?.cancel()
        progressJob = null
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
        _playbackState.value = AudioPlaybackState()
    }

    private fun startProgressLoop() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                val mp = mediaPlayer ?: break
                if (mp.isPlaying) {
                    _playbackState.value = _playbackState.value.copy(
                        currentPositionMs = mp.currentPosition.toLong(),
                        durationMs = mp.duration.toLong().coerceAtLeast(_playbackState.value.durationMs)
                    )
                }
                delay(120L)
            }
        }
    }
}
