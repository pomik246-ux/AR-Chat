package com.archat.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.PropertyName

data class UserProfile(
    val uid: String = "",
    val displayName: String = "",
    val displayNameLower: String = "",
    val username: String = "",
    val usernameLower: String = "",
    val photoUrl: String = "",
    val bio: String = "",
    @get:PropertyName("isOnline") @set:PropertyName("isOnline")
    var isOnline: Boolean = false,
    val lastSeen: Timestamp? = null,
    val privacyShowLastSeen: String = "everyone", // everyone | contacts | nobody
    val privacyShowOnline: Boolean = true,
    val privacyShowPhoto: String = "everyone",    // everyone | contacts | nobody
    val privacyWhoCanMessage: String = "everyone", // everyone | contacts
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class UserPrivateInfo(
    val uid: String = "",
    val email: String = "",
    val notifyPrivateMessages: Boolean = true,
    val notifyGroupMessages: Boolean = true,
    val notifyChatInvites: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val showMessagePreview: Boolean = true,
    val updatedAt: Timestamp? = null
)

data class UsernameReservation(
    val uid: String = "",
    val username: String = "",
    val createdAt: Timestamp? = null
)
