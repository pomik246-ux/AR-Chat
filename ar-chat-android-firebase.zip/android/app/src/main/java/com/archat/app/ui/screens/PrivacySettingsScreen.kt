package com.archat.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.archat.app.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySettingsScreen(
    settingsViewModel: SettingsViewModel,
    onNavigateBack: () -> Unit
) {
    val profile by settingsViewModel.myProfile.collectAsStateWithLifecycle()
    val statusMsg by settingsViewModel.statusMessage.collectAsStateWithLifecycle()

    var showLastSeen by remember { mutableStateOf("everyone") }
    var showOnline by remember { mutableStateOf(true) }
    var showPhoto by remember { mutableStateOf("everyone") }
    var whoCanMessage by remember { mutableStateOf("everyone") }

    LaunchedEffect(profile) {
        profile?.let {
            showLastSeen = it.privacyShowLastSeen
            showOnline = it.privacyShowOnline
            showPhoto = it.privacyShowPhoto
            whoCanMessage = it.privacyWhoCanMessage
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Privacy Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Show Online Status", style = MaterialTheme.typography.titleMedium)
                    Text("Display when you are actively connected", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = showOnline, onCheckedChange = { showOnline = it })
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

            Text("Who can see my Last Seen", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            listOf("everyone" to "Everyone", "contacts" to "My Contacts", "nobody" to "Nobody").forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = showLastSeen == key, onClick = { showLastSeen = key })
                    Text(label)
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

            Text("Who can see my Profile Photo", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            listOf("everyone" to "Everyone", "contacts" to "My Contacts", "nobody" to "Nobody").forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = showPhoto == key, onClick = { showPhoto = key })
                    Text(label)
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

            Text("Who can message me", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            listOf("everyone" to "Everyone", "contacts" to "Contacts only").forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = whoCanMessage == key, onClick = { whoCanMessage = key })
                    Text(label)
                }
            }

            statusMsg?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.primary)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    settingsViewModel.savePrivacy(showLastSeen, showOnline, showPhoto, whoCanMessage)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Privacy Settings")
            }
        }
    }
}
