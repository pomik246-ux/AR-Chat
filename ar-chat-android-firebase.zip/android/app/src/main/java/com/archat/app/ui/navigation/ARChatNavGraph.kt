package com.archat.app.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.archat.app.data.repository.AuthSessionState
import com.archat.app.ui.screens.BlockedUsersScreen
import com.archat.app.ui.screens.CreateGroupScreen
import com.archat.app.ui.screens.EditProfileScreen
import com.archat.app.ui.screens.EmailVerificationScreen
import com.archat.app.ui.screens.ForgotPasswordScreen
import com.archat.app.ui.screens.GroupChatScreen
import com.archat.app.ui.screens.GroupDetailsScreen
import com.archat.app.ui.screens.GroupMembersScreen
import com.archat.app.ui.screens.ImageViewerScreen
import com.archat.app.ui.screens.LoginScreen
import com.archat.app.ui.screens.MainChatsScreen
import com.archat.app.ui.screens.NewChatScreen
import com.archat.app.ui.screens.NotificationSettingsScreen
import com.archat.app.ui.screens.PrivacySettingsScreen
import com.archat.app.ui.screens.PrivateChatScreen
import com.archat.app.ui.screens.RegisterScreen
import com.archat.app.ui.screens.SearchUsersScreen
import com.archat.app.ui.screens.SplashScreen
import com.archat.app.ui.screens.UserProfileScreen
import com.archat.app.ui.viewmodel.AuthViewModel
import com.archat.app.ui.viewmodel.HomeViewModel
import com.archat.app.ui.viewmodel.SearchAndProfileViewModel
import com.archat.app.ui.viewmodel.SettingsViewModel

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"
    const val EMAIL_VERIFICATION = "email_verification"
    const val MAIN_CHATS = "main_chats"
    const val SEARCH_USERS = "search_users"
    const val NEW_CHAT = "new_chat"
    const val CREATE_GROUP = "create_group"
    const val USER_PROFILE = "user_profile/{uid}"
    const val PRIVATE_CHAT = "private_chat/{chatId}"
    const val GROUP_CHAT = "group_chat/{groupId}"
    const val GROUP_DETAILS = "group_details/{groupId}"
    const val GROUP_MEMBERS = "group_members/{groupId}"
    const val IMAGE_VIEWER = "image_viewer?url={url}"
    const val EDIT_PROFILE = "edit_profile"
    const val PRIVACY_SETTINGS = "privacy_settings"
    const val BLOCKED_USERS = "blocked_users"
    const val NOTIFICATION_SETTINGS = "notification_settings"
}

@Composable
fun ARChatNavGraph(
    authViewModel: AuthViewModel,
    settingsViewModel: SettingsViewModel,
    pendingNotificationRoute: String?,
    onNotificationRouteHandled: () -> Unit
) {
    val navController = rememberNavController()
    val sessionState by authViewModel.sessionState.collectAsStateWithLifecycle()

    val homeViewModel: HomeViewModel = viewModel()
    val searchViewModel: SearchAndProfileViewModel = viewModel()

    LaunchedEffect(sessionState) {
        when (sessionState) {
            is AuthSessionState.Loading -> Unit
            is AuthSessionState.Unauthenticated -> {
                settingsViewModel.refreshUid()
                navController.navigate(Routes.LOGIN) {
                    popUpTo(0) { inclusive = true }
                }
            }
            is AuthSessionState.Unverified -> {
                navController.navigate(Routes.EMAIL_VERIFICATION) {
                    popUpTo(0) { inclusive = true }
                }
            }
            is AuthSessionState.Authenticated -> {
                settingsViewModel.refreshUid()
                navController.navigate(Routes.MAIN_CHATS) {
                    popUpTo(0) { inclusive = true }
                }
            }
        }
    }

    LaunchedEffect(pendingNotificationRoute, sessionState) {
        if (pendingNotificationRoute != null && sessionState is AuthSessionState.Authenticated) {
            navController.navigate(pendingNotificationRoute)
            onNotificationRouteHandled()
        }
    }

    NavHost(
        navController = navController,
        startDestination = Routes.SPLASH
    ) {
        composable(Routes.SPLASH) {
            SplashScreen()
        }

        composable(Routes.LOGIN) {
            LoginScreen(
                authViewModel = authViewModel,
                onNavigateToRegister = { navController.navigate(Routes.REGISTER) },
                onNavigateToForgotPassword = { navController.navigate(Routes.FORGOT_PASSWORD) }
            )
        }

        composable(Routes.REGISTER) {
            RegisterScreen(
                authViewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.FORGOT_PASSWORD) {
            ForgotPasswordScreen(
                authViewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.EMAIL_VERIFICATION) {
            val email = (sessionState as? AuthSessionState.Unverified)?.user?.email ?: ""
            EmailVerificationScreen(
                email = email,
                authViewModel = authViewModel,
                onVerified = {
                    settingsViewModel.refreshUid()
                    navController.navigate(Routes.MAIN_CHATS) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.MAIN_CHATS) {
            MainChatsScreen(
                homeViewModel = homeViewModel,
                searchViewModel = searchViewModel,
                settingsViewModel = settingsViewModel,
                onOpenPrivateChat = { chatId -> navController.navigate("private_chat/$chatId") },
                onOpenGroupChat = { groupId -> navController.navigate("group_chat/$groupId") },
                onOpenNewChat = { navController.navigate(Routes.NEW_CHAT) },
                onOpenCreateGroup = { navController.navigate(Routes.CREATE_GROUP) },
                onOpenUserProfile = { uid -> navController.navigate("user_profile/$uid") },
                onOpenEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
                onOpenPrivacySettings = { navController.navigate(Routes.PRIVACY_SETTINGS) },
                onOpenBlockedUsers = { navController.navigate(Routes.BLOCKED_USERS) },
                onOpenNotificationSettings = { navController.navigate(Routes.NOTIFICATION_SETTINGS) }
            )
        }

        composable(Routes.SEARCH_USERS) {
            SearchUsersScreen(
                searchViewModel = searchViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenUserProfile = { uid -> navController.navigate("user_profile/$uid") },
                onOpenChat = { chatId -> navController.navigate("private_chat/$chatId") }
            )
        }

        composable(Routes.NEW_CHAT) {
            NewChatScreen(
                searchViewModel = searchViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenCreateGroup = { navController.navigate(Routes.CREATE_GROUP) },
                onOpenPrivateChat = { chatId ->
                    navController.navigate("private_chat/$chatId") {
                        popUpTo(Routes.MAIN_CHATS)
                    }
                },
                onOpenUserProfile = { uid -> navController.navigate("user_profile/$uid") }
            )
        }

        composable(Routes.CREATE_GROUP) {
            CreateGroupScreen(
                searchViewModel = searchViewModel,
                onNavigateBack = { navController.popBackStack() },
                onGroupCreated = { groupId ->
                    navController.navigate("group_chat/$groupId") {
                        popUpTo(Routes.MAIN_CHATS)
                    }
                }
            )
        }

        composable(
            route = Routes.USER_PROFILE,
            arguments = listOf(navArgument("uid") { type = NavType.StringType })
        ) { backStack ->
            val uid = backStack.arguments?.getString("uid") ?: ""
            UserProfileScreen(
                uid = uid,
                searchViewModel = searchViewModel,
                settingsViewModel = settingsViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenChat = { chatId -> navController.navigate("private_chat/$chatId") }
            )
        }

        composable(
            route = Routes.PRIVATE_CHAT,
            arguments = listOf(navArgument("chatId") { type = NavType.StringType })
        ) { backStack ->
            val chatId = backStack.arguments?.getString("chatId") ?: ""
            PrivateChatScreen(
                chatId = chatId,
                searchViewModel = searchViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenProfile = { uid -> navController.navigate("user_profile/$uid") },
                onOpenImageViewer = { url ->
                    navController.navigate("image_viewer?url=${Uri.encode(url)}")
                }
            )
        }

        composable(
            route = Routes.GROUP_CHAT,
            arguments = listOf(navArgument("groupId") { type = NavType.StringType })
        ) { backStack ->
            val groupId = backStack.arguments?.getString("groupId") ?: ""
            GroupChatScreen(
                groupId = groupId,
                onNavigateBack = { navController.popBackStack() },
                onOpenGroupDetails = { gid -> navController.navigate("group_details/$gid") },
                onOpenImageViewer = { url ->
                    navController.navigate("image_viewer?url=${Uri.encode(url)}")
                }
            )
        }

        composable(
            route = Routes.GROUP_DETAILS,
            arguments = listOf(navArgument("groupId") { type = NavType.StringType })
        ) { backStack ->
            val groupId = backStack.arguments?.getString("groupId") ?: ""
            GroupDetailsScreen(
                groupId = groupId,
                onNavigateBack = { navController.popBackStack() },
                onOpenGroupMembers = { gid -> navController.navigate("group_members/$gid") },
                onLeftGroup = {
                    navController.navigate(Routes.MAIN_CHATS) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Routes.GROUP_MEMBERS,
            arguments = listOf(navArgument("groupId") { type = NavType.StringType })
        ) { backStack ->
            val groupId = backStack.arguments?.getString("groupId") ?: ""
            GroupMembersScreen(
                groupId = groupId,
                searchViewModel = searchViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenUserProfile = { uid -> navController.navigate("user_profile/$uid") }
            )
        }

        composable(
            route = Routes.IMAGE_VIEWER,
            arguments = listOf(navArgument("url") { type = NavType.StringType; defaultValue = "" })
        ) { backStack ->
            val url = backStack.arguments?.getString("url") ?: ""
            ImageViewerScreen(
                imageUrl = Uri.decode(url),
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.EDIT_PROFILE) {
            EditProfileScreen(
                settingsViewModel = settingsViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.PRIVACY_SETTINGS) {
            PrivacySettingsScreen(
                settingsViewModel = settingsViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.BLOCKED_USERS) {
            BlockedUsersScreen(
                settingsViewModel = settingsViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.NOTIFICATION_SETTINGS) {
            NotificationSettingsScreen(
                settingsViewModel = settingsViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
