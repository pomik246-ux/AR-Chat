package com.archat.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

class ARChatApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        configureAppCheck()
        createNotificationChannels()
        FirebaseServiceLocator.initialize(this)
    }

    private fun configureAppCheck() {
        val firebaseAppCheck = FirebaseAppCheck.getInstance()
        val providerFactory = if (BuildConfig.DEBUG) {
            DebugAppCheckProviderFactory.getInstance()
        } else {
            PlayIntegrityAppCheckProviderFactory.getInstance()
        }
        firebaseAppCheck.installAppCheckProviderFactory(providerFactory)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_PRIVATE_MESSAGES,
                    getString(R.string.channel_private_name),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = getString(R.string.channel_private_desc)
                    enableVibration(true)
                },
                NotificationChannel(
                    CHANNEL_GROUP_MESSAGES,
                    getString(R.string.channel_group_name),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = getString(R.string.channel_group_desc)
                    enableVibration(true)
                },
                NotificationChannel(
                    CHANNEL_CHAT_INVITES,
                    getString(R.string.channel_invites_name),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = getString(R.string.channel_invites_desc)
                }
            )
            manager.createNotificationChannels(channels)
        }
    }

    companion object {
        const val CHANNEL_PRIVATE_MESSAGES = "messages_private"
        const val CHANNEL_GROUP_MESSAGES = "messages_group"
        const val CHANNEL_CHAT_INVITES = "chat_invites"
    }
}
