package com.archat.app.data.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

/**
 * Reliable presence manager combining Firebase Realtime Database (.info/connected + onDisconnect)
 * with Firestore profile presence synchronization so users are never stuck permanently online.
 */
class PresenceManager(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
    private val realtimeDb: FirebaseDatabase?
) {
    private var connectedListener: ValueEventListener? = null
    private var activeUid: String? = null

    fun startPresence() {
        val user = auth.currentUser ?: return
        if (!user.isEmailVerified) return
        val uid = user.uid
        if (activeUid == uid && connectedListener != null) {
            setOnlineFirestore(uid, true)
            return
        }
        stopPresence()
        activeUid = uid

        val db = realtimeDb
        if (db != null) {
            try {
                val presenceRef = db.getReference("presence/$uid")
                val connectedRef = db.getReference(".info/connected")
                val listener = object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val connected = snapshot.getValue(Boolean::class.java) ?: false
                        if (connected) {
                            presenceRef.onDisconnect().setValue(
                                mapOf("online" to false, "lastChanged" to ServerValue.TIMESTAMP)
                            )
                            presenceRef.setValue(
                                mapOf("online" to true, "lastChanged" to ServerValue.TIMESTAMP)
                            )
                            setOnlineFirestore(uid, true)
                        }
                    }

                    override fun onCancelled(error: DatabaseError) = Unit
                }
                connectedListener = listener
                connectedRef.addValueEventListener(listener)
            } catch (_: Exception) {
                setOnlineFirestore(uid, true)
            }
        } else {
            setOnlineFirestore(uid, true)
        }
    }

    fun goOffline() {
        val uid = activeUid ?: auth.currentUser?.uid ?: return
        try {
            realtimeDb?.getReference("presence/$uid")?.setValue(
                mapOf("online" to false, "lastChanged" to ServerValue.TIMESTAMP)
            )
        } catch (_: Exception) {
        }
        setOnlineFirestore(uid, false)
    }

    fun stopPresence() {
        val listener = connectedListener
        if (listener != null) {
            try {
                realtimeDb?.getReference(".info/connected")?.removeEventListener(listener)
            } catch (_: Exception) {
            }
        }
        connectedListener = null
        goOffline()
        activeUid = null
    }

    private fun setOnlineFirestore(uid: String, online: Boolean) {
        val user = auth.currentUser ?: return
        if (!user.isEmailVerified) return
        firestore.collection("users").document(uid)
            .update(
                mapOf(
                    "isOnline" to online,
                    "lastSeen" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
    }
}
