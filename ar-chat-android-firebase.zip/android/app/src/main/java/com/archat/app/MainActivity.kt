package com.archat.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.archat.app.data.firebase.ARChatMessagingService
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.ui.navigation.ARChatNavGraph
import com.archat.app.ui.theme.ARChatTheme
import com.archat.app.ui.viewmodel.AuthViewModel
import com.archat.app.ui.viewmodel.SettingsViewModel

class MainActivity : ComponentActivity() {

    private var pendingNotificationRoute by mutableStateOf<String?>(null)

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        requestNotificationPermissionIfNeeded()
        handleNotificationIntent(intent)

        setContent {
            val authViewModel: AuthViewModel = viewModel()
            val settingsViewModel: SettingsViewModel = viewModel()
            val darkOverride by settingsViewModel.isDarkModeOverride.collectAsStateWithLifecycle()
            val darkTheme = darkOverride ?: isSystemInDarkTheme()

            ARChatTheme(darkTheme = darkTheme) {
                ARChatNavGraph(
                    authViewModel = authViewModel,
                    settingsViewModel = settingsViewModel,
                    pendingNotificationRoute = pendingNotificationRoute,
                    onNotificationRouteHandled = { pendingNotificationRoute = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleNotificationIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        FirebaseServiceLocator.presenceManager.startPresence()
    }

    override fun onStop() {
        super.onStop()
        FirebaseServiceLocator.presenceManager.goOffline()
    }

    private fun handleNotificationIntent(intent: Intent?) {
        val chatId = intent?.getStringExtra(ARChatMessagingService.EXTRA_CHAT_ID) ?: return
        if (chatId.isBlank()) return
        val chatType = intent.getStringExtra(ARChatMessagingService.EXTRA_CHAT_TYPE) ?: "private"
        pendingNotificationRoute = if (chatType == "group") {
            "group_chat/$chatId"
        } else {
            "private_chat/$chatId"
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
