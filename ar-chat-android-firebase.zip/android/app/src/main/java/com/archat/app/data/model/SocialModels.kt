package com.archat.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.PropertyName

data class UserContact(
    val contactUid: String = "",
    val ownerUid: String = "",
    val displayName: String = "",
    val username: String = "",
    val photoUrl: String = "",
    @get:PropertyName("isFavorite") @set:PropertyName("isFavorite")
    var isFavorite: Boolean = false,
    val createdAt: Timestamp? = null
)

data class BlockedUser(
    val blockedUid: String = "",
    val ownerUid: String = "",
    val displayName: String = "",
    val username: String = "",
    val photoUrl: String = "",
    val createdAt: Timestamp? = null
)

data class UserDevice(
    val tokenId: String = "",
    val uid: String = "",
    val token: String = "",
    val platform: String = "android",
    val updatedAt: Timestamp? = null
)

data class NotificationItem(
    val notificationId: String = "",
    val recipientUid: String = "",
    val type: String = "",
    val title: String = "",
    val body: String = "",
    val targetId: String = "",
    @get:PropertyName("isRead") @set:PropertyName("isRead")
    var isRead: Boolean = false,
    val createdAt: Timestamp? = null
)

data class UserReport(
    val reportId: String = "",
    val reporterUid: String = "",
    val reportedUid: String = "",
    val reason: String = "spam",
    val details: String = "",
    val status: String = "pending",
    val createdAt: Timestamp? = null
)
