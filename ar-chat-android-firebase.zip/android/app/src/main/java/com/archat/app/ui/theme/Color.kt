package com.archat.app.ui.theme

import androidx.compose.ui.graphics.Color

val ARGreen = Color(0xFF00A86B)
val ARGreenDark = Color(0xFF057A55)
val ARGreenSoft = Color(0xFFE6F7F0)
val ARGreenDarkSurface = Color(0xFF0D2E22)

val LightBackground = Color(0xFFFDFEFE)
val LightSurface = Color(0xFFF4F7F6)
val LightCard = Color(0xFFFFFFFF)
val LightBorder = Color(0xFFE2E8E5)
val LightTextPrimary = Color(0xFF0F1A15)
val LightTextSecondary = Color(0xFF5C6B64)

val DarkBackground = Color(0xFF0B110E)
val DarkSurface = Color(0xFF131C18)
val DarkCard = Color(0xFF19241F)
val DarkBorder = Color(0xFF26352E)
val DarkTextPrimary = Color(0xFFF1F5F3)
val DarkTextSecondary = Color(0xFF98A8A0)

val OutgoingBubbleLight = Color(0xFF00A86B)
val OutgoingBubbleDark = Color(0xFF057A55)
val IncomingBubbleLight = Color(0xFFF0F4F2)
val IncomingBubbleDark = Color(0xFF1B2722)

val TickReadColor = Color(0xFF38BDF8)
val TickDefaultColor = Color(0xFF94A3B8)
val DangerRed = Color(0xFFDC2626)
val WarningAmber = Color(0xFFD97706)
