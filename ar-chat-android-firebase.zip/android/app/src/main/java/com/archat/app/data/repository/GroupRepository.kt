package com.archat.app.data.repository

import android.net.Uri
import com.archat.app.data.model.ChatMessage
import com.archat.app.data.model.GroupChat
import com.archat.app.data.model.GroupMember
import com.archat.app.data.model.UserProfile
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class GroupRepository(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
    private val storageRepository: StorageRepository
) {
    fun currentUid(): String? = auth.currentUser?.uid

    fun observeMyGroups(): Flow<List<GroupChat>> = callbackFlow {
        val uid = currentUid() ?: run {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val reg = firestore.collection("groups")
            .whereArrayContains("memberIds", uid)
            .orderBy("lastMessageAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap?.toObjects(GroupChat::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeGroup(groupId: String): Flow<GroupChat?> = callbackFlow {
        val reg = firestore.collection("groups").document(groupId)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObject(GroupChat::class.java))
            }
        awaitClose { reg.remove() }
    }

    fun observeGroupMembers(groupId: String): Flow<List<GroupMember>> = callbackFlow {
        val reg = firestore.collection("groups").document(groupId)
            .collection("members")
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(GroupMember::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun createGroup(
        name: String,
        description: String,
        photoUri: Uri?,
        creator: UserProfile,
        initialMembers: List<UserProfile>
    ): Result<String> = runCatching {
        val myUid = currentUid() ?: error("Not authenticated")
        val groupId = UUID.randomUUID().toString()
        val photoUrl = if (photoUri != null) {
            storageRepository.uploadGroupPhoto(groupId, photoUri).getOrDefault("")
        } else ""

        val allProfiles = (listOf(creator) + initialMembers).distinctBy { it.uid }
        val memberIds = allProfiles.map { it.uid }
        val unreadMap = memberIds.associateWith { 0L }

        val batch = firestore.batch()
        val groupRef = firestore.collection("groups").document(groupId)

        batch.set(
            groupRef,
            mapOf(
                "groupId" to groupId,
                "name" to name.trim().take(80),
                "description" to description.trim().take(300),
                "photoUrl" to photoUrl,
                "createdBy" to myUid,
                "memberIds" to memberIds,
                "adminIds" to listOf(myUid),
                "lastMessageText" to "${creator.displayName} created group \"${name.trim()}\"",
                "lastMessageType" to "system",
                "lastMessageSenderId" to myUid,
                "lastMessageAt" to FieldValue.serverTimestamp(),
                "unreadCounts" to unreadMap,
                "typingUsers" to emptyMap<String, Any>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )

        allProfiles.forEach { profile ->
            val memberRef = groupRef.collection("members").document(profile.uid)
            batch.set(
                memberRef,
                mapOf(
                    "uid" to profile.uid,
                    "groupId" to groupId,
                    "role" to if (profile.uid == myUid) "admin" else "member",
                    "displayName" to profile.displayName.ifBlank { profile.username },
                    "username" to profile.username,
                    "photoUrl" to profile.photoUrl,
                    "muted" to false,
                    "joinedAt" to FieldValue.serverTimestamp()
                )
            )
        }

        batch.commit().await()
        groupId
    }

    fun observeGroupMessages(groupId: String, pageSize: Long = 35L): Flow<Pair<List<ChatMessage>, DocumentSnapshot?>> = callbackFlow {
        val reg = firestore.collection("groups").document(groupId)
            .collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(pageSize)
            .addSnapshotListener { snap, error ->
                if (error != null) {
                    trySend(emptyList<ChatMessage>() to null)
                    return@addSnapshotListener
                }
                val docs = snap?.documents ?: emptyList()
                val messages = docs.mapNotNull { it.toObject(ChatMessage::class.java) }.reversed()
                trySend(messages to docs.lastOrNull())
            }
        awaitClose { reg.remove() }
    }

    suspend fun loadOlderGroupMessages(
        groupId: String,
        oldestSnapshot: DocumentSnapshot,
        pageSize: Long = 30L
    ): Result<Pair<List<ChatMessage>, DocumentSnapshot?>> = runCatching {
        val snap = firestore.collection("groups").document(groupId)
            .collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .startAfter(oldestSnapshot)
            .limit(pageSize)
            .get()
            .await()
        val docs = snap.documents
        docs.mapNotNull { it.toObject(ChatMessage::class.java) }.reversed() to docs.lastOrNull()
    }

    suspend fun sendGroupMessage(
        groupId: String,
        sender: UserProfile,
        memberIds: List<String>,
        type: String,
        text: String,
        mediaUrl: String = "",
        mediaDurationMs: Long = 0L,
        replyTo: ChatMessage? = null,
        isForwarded: Boolean = false,
        customMessageId: String = UUID.randomUUID().toString()
    ): Result<String> = runCatching {
        val myUid = currentUid() ?: error("Not authenticated")
        val groupRef = firestore.collection("groups").document(groupId)
        val msgRef = groupRef.collection("messages").document(customMessageId)

        val previewText = when (type) {
            "image" -> "${sender.displayName}: 📷 Photo"
            "audio" -> "${sender.displayName}: 🎙️ Voice message"
            else -> "${sender.displayName}: ${text.take(400)}"
        }

        val payload = mutableMapOf<String, Any>(
            "messageId" to customMessageId,
            "senderId" to myUid,
            "senderName" to sender.displayName.ifBlank { sender.username },
            "senderPhotoUrl" to sender.photoUrl,
            "type" to type,
            "text" to text.take(4000),
            "isForwarded" to isForwarded,
            "status" to "sent",
            "deliveredTo" to emptyList<String>(),
            "readBy" to emptyList<String>(),
            "deletedFor" to emptyList<String>(),
            "isDeletedForEveryone" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (mediaUrl.isNotBlank()) payload["mediaUrl"] = mediaUrl
        if (mediaDurationMs > 0L) payload["mediaDurationMs"] = mediaDurationMs
        if (replyTo != null) {
            payload["replyToMessageId"] = replyTo.messageId
            payload["replyToText"] = replyTo.text.take(300)
            payload["replyToSenderName"] = replyTo.senderName
        }

        firestore.runTransaction { tx ->
            val groupSnap = tx.get(groupRef)
            val updates = mutableMapOf<String, Any>(
                "lastMessageText" to previewText.take(500),
                "lastMessageType" to type,
                "lastMessageSenderId" to myUid,
                "lastMessageAt" to FieldValue.serverTimestamp(),
                "typingUsers.$myUid" to FieldValue.delete(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            memberIds.filter { it != myUid }.forEach { uid ->
                val current = (groupSnap.get("unreadCounts.$uid") as? Long) ?: 0L
                updates["unreadCounts.$uid"] = current + 1L
            }
            tx.set(msgRef, payload)
            tx.update(groupRef, updates)
        }.await()

        customMessageId
    }

    suspend fun clearGroupUnread(groupId: String) {
        val myUid = currentUid() ?: return
        runCatching {
            firestore.collection("groups").document(groupId)
                .update(
                    mapOf(
                        "unreadCounts.$myUid" to 0L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        }
    }

    suspend fun setGroupTyping(groupId: String, isTyping: Boolean) {
        val myUid = currentUid() ?: return
        runCatching {
            val value: Any = if (isTyping) Timestamp.now() else FieldValue.delete()
            firestore.collection("groups").document(groupId)
                .update(
                    mapOf(
                        "typingUsers.$myUid" to value,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
        }
    }

    suspend fun updateGroupInfo(groupId: String, name: String, description: String, newPhotoUri: Uri?): Result<Unit> = runCatching {
        val updates = mutableMapOf<String, Any>(
            "name" to name.trim().take(80),
            "description" to description.trim().take(300),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (newPhotoUri != null) {
            val url = storageRepository.uploadGroupPhoto(groupId, newPhotoUri).getOrThrow()
            updates["photoUrl"] = url
        }
        firestore.collection("groups").document(groupId).update(updates).await()
    }

    suspend fun addGroupMember(groupId: String, user: UserProfile): Result<Unit> = runCatching {
        val groupRef = firestore.collection("groups").document(groupId)
        val memberRef = groupRef.collection("members").document(user.uid)
        val batch = firestore.batch()
        batch.update(
            groupRef,
            mapOf(
                "memberIds" to FieldValue.arrayUnion(user.uid),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            memberRef,
            mapOf(
                "uid" to user.uid,
                "groupId" to groupId,
                "role" to "member",
                "displayName" to user.displayName.ifBlank { user.username },
                "username" to user.username,
                "photoUrl" to user.photoUrl,
                "muted" to false,
                "joinedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
    }

    suspend fun removeGroupMember(groupId: String, targetUid: String): Result<Unit> = runCatching {
        val groupRef = firestore.collection("groups").document(groupId)
        val memberRef = groupRef.collection("members").document(targetUid)
        val batch = firestore.batch()
        batch.update(
            groupRef,
            mapOf(
                "memberIds" to FieldValue.arrayRemove(targetUid),
                "adminIds" to FieldValue.arrayRemove(targetUid),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.delete(memberRef)
        batch.commit().await()
    }

    suspend fun setMemberAdminRole(groupId: String, targetUid: String, makeAdmin: Boolean): Result<Unit> = runCatching {
        val groupRef = firestore.collection("groups").document(groupId)
        val memberRef = groupRef.collection("members").document(targetUid)
        val batch = firestore.batch()
        batch.update(
            groupRef,
            mapOf(
                "adminIds" to if (makeAdmin) FieldValue.arrayUnion(targetUid) else FieldValue.arrayRemove(targetUid),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.update(memberRef, "role", if (makeAdmin) "admin" else "member")
        batch.commit().await()
    }

    suspend fun toggleMuteGroup(groupId: String, muted: Boolean): Result<Unit> = runCatching {
        val myUid = currentUid() ?: error("Not authenticated")
        firestore.collection("groups").document(groupId)
            .collection("members").document(myUid)
            .update("muted", muted).await()
    }

    suspend fun leaveGroup(groupId: String): Result<Unit> = runCatching {
        val myUid = currentUid() ?: error("Not authenticated")
        val groupRef = firestore.collection("groups").document(groupId)
        val memberRef = groupRef.collection("members").document(myUid)
        val batch = firestore.batch()
        batch.update(
            groupRef,
            mapOf(
                "memberIds" to FieldValue.arrayRemove(myUid),
                "adminIds" to FieldValue.arrayRemove(myUid),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.delete(memberRef)
        batch.commit().await()
    }

    suspend fun deleteGroupMessageForEveryone(groupId: String, messageId: String): Result<Unit> = runCatching {
        firestore.collection("groups").document(groupId)
            .collection("messages").document(messageId)
            .update(
                mapOf(
                    "isDeletedForEveryone" to true,
                    "text" to "This message was deleted",
                    "mediaUrl" to "",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
    }
}
