package com.archat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.data.repository.AuthSessionState
import com.archat.app.utils.ValidationUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val infoMessage: String? = null,
    val resetSent: Boolean = false
)

class AuthViewModel : ViewModel() {
    private val authRepo = FirebaseServiceLocator.authRepository

    val sessionState: StateFlow<AuthSessionState> = authRepo.observeAuthState()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AuthSessionState.Loading)

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(error = null, infoMessage = null, resetSent = false)
    }

    fun login(email: String, password: String) {
        val emailErr = ValidationUtils.validateEmail(email)
        if (emailErr != null) {
            _uiState.value = AuthUiState(error = emailErr)
            return
        }
        if (password.isBlank()) {
            _uiState.value = AuthUiState(error = "Password is required")
            return
        }

        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepo.login(email, password)
                .onSuccess {
                    _uiState.value = AuthUiState(isLoading = false)
                }
                .onFailure { e ->
                    _uiState.value = AuthUiState(isLoading = false, error = mapAuthError(e))
                }
        }
    }

    fun register(
        fullName: String,
        username: String,
        email: String,
        password: String,
        photoUri: Uri?
    ) {
        val nameErr = ValidationUtils.validateDisplayName(fullName)
        val userErr = ValidationUtils.validateUsername(username)
        val emailErr = ValidationUtils.validateEmail(email)
        val passErr = ValidationUtils.validatePassword(password)
        val firstErr = nameErr ?: userErr ?: emailErr ?: passErr
        if (firstErr != null) {
            _uiState.value = AuthUiState(error = firstErr)
            return
        }

        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepo.register(fullName, username, email, password, photoUri)
                .onSuccess {
                    _uiState.value = AuthUiState(
                        isLoading = false,
                        infoMessage = "Verification link sent to $email"
                    )
                }
                .onFailure { e ->
                    _uiState.value = AuthUiState(isLoading = false, error = mapAuthError(e))
                }
        }
    }

    fun resendVerificationEmail() {
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepo.resendVerificationEmail()
                .onSuccess {
                    _uiState.value = AuthUiState(infoMessage = "Verification email resent. Check your inbox.")
                }
                .onFailure { e ->
                    _uiState.value = AuthUiState(error = mapAuthError(e))
                }
        }
    }

    fun checkVerificationStatus(onVerified: () -> Unit) {
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepo.refreshVerificationStatus()
                .onSuccess { verified ->
                    if (verified) {
                        _uiState.value = AuthUiState()
                        onVerified()
                    } else {
                        _uiState.value = AuthUiState(
                            error = "Email is not verified yet. Please tap the link in your inbox."
                        )
                    }
                }
                .onFailure { e ->
                    _uiState.value = AuthUiState(error = mapAuthError(e))
                }
        }
    }

    fun sendPasswordReset(email: String) {
        val emailErr = ValidationUtils.validateEmail(email)
        if (emailErr != null) {
            _uiState.value = AuthUiState(error = emailErr)
            return
        }
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepo.sendPasswordReset(email)
                .onSuccess {
                    _uiState.value = AuthUiState(
                        resetSent = true,
                        infoMessage = "Password reset link sent to $email"
                    )
                }
                .onFailure { e ->
                    _uiState.value = AuthUiState(error = mapAuthError(e))
                }
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepo.logout()
        }
    }

    private fun mapAuthError(t: Throwable): String {
        val msg = t.localizedMessage ?: return "Authentication error"
        return when {
            msg.contains("password is invalid", ignoreCase = true) ||
                msg.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ->
                "Incorrect email or password."
            msg.contains("no user record", ignoreCase = true) ->
                "No account found with this email."
            msg.contains("already in use", ignoreCase = true) ->
                "An account already exists with this email."
            msg.contains("network", ignoreCase = true) ->
                "Network error. Please check your internet connection."
            else -> msg
        }
    }
}
