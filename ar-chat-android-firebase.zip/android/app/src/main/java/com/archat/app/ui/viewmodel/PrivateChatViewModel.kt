package com.archat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.data.model.ChatMessage
import com.archat.app.data.model.PrivateChat
import com.archat.app.data.model.UserProfile
import com.archat.app.data.repository.UploadProgress
import com.archat.app.utils.AudioPlaybackState
import com.archat.app.utils.ChatIdUtils
import com.archat.app.utils.RecordingState
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class PrivateChatUiState(
    val chatId: String = "",
    val peerUid: String = "",
    val peerProfile: UserProfile? = null,
    val myProfile: UserProfile? = null,
    val chat: PrivateChat? = null,
    val messages: List<ChatMessage> = emptyList(),
    val olderMessages: List<ChatMessage> = emptyList(),
    val uploadProgress: Map<String, Float> = emptyMap(),
    val failedMessages: List<ChatMessage> = emptyList(),
    val isBlocked: Boolean = false,
    val isLoadingMore: Boolean = false,
    val hasMoreOlder: Boolean = true,
    val replyingTo: ChatMessage? = null,
    val previewAudio: Pair<File, Long>? = null,
    val error: String? = null
)

class PrivateChatViewModel : ViewModel() {
    private val chatRepo = FirebaseServiceLocator.chatRepository
    private val userRepo = FirebaseServiceLocator.userRepository
    private val storageRepo = FirebaseServiceLocator.storageRepository
    private val audioRecorder = FirebaseServiceLocator.audioRecorder
    private val audioPlayer = FirebaseServiceLocator.audioPlayer

    private val _uiState = MutableStateFlow(PrivateChatUiState())
    val uiState: StateFlow<PrivateChatUiState> = _uiState.asStateFlow()

    val recordingState: StateFlow<RecordingState> = audioRecorder.state
    val playbackState: StateFlow<AudioPlaybackState> = audioPlayer.playbackState

    private var oldestSnapshot: DocumentSnapshot? = null
    private var typingJob: Job? = null
    private var listenersStartedFor: String? = null

    fun loadChat(chatId: String) {
        if (listenersStartedFor == chatId) return
        listenersStartedFor = chatId
        val myUid = chatRepo.currentUid() ?: return

        _uiState.value = _uiState.value.copy(chatId = chatId)

        viewModelScope.launch {
            userRepo.observeUserProfile(myUid).collect { me ->
                _uiState.value = _uiState.value.copy(myProfile = me)
            }
        }

        viewModelScope.launch {
            chatRepo.observeChat(chatId).collect { chat ->
                val peerUid = chat?.let { ChatIdUtils.peerUidFromChat(it.participants, myUid) }
                    ?: chatId.split("_").firstOrNull { it != myUid } ?: ""
                _uiState.value = _uiState.value.copy(chat = chat, peerUid = peerUid)
                if (peerUid.isNotBlank() && _uiState.value.peerProfile == null) {
                    observePeer(peerUid)
                }
            }
        }

        viewModelScope.launch {
            chatRepo.observeRecentMessages(chatId).collect { (msgs, oldest) ->
                if (oldestSnapshot == null) oldestSnapshot = oldest
                val visible = msgs.filter { !it.deletedFor.contains(myUid) }
                _uiState.value = _uiState.value.copy(messages = visible)
                chatRepo.markMessagesDeliveredAndRead(chatId, msgs)
            }
        }
    }

    private fun observePeer(peerUid: String) {
        viewModelScope.launch {
            userRepo.observeUserProfile(peerUid).collect { peer ->
                val blocked = userRepo.isBlockedEitherWay(peerUid)
                _uiState.value = _uiState.value.copy(peerProfile = peer, isBlocked = blocked)
            }
        }
    }

    fun loadOlderMessages() {
        val snap = oldestSnapshot ?: return
        if (_uiState.value.isLoadingMore || !_uiState.value.hasMoreOlder) return
        val myUid = chatRepo.currentUid() ?: return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingMore = true)
            chatRepo.loadOlderMessages(_uiState.value.chatId, snap)
                .onSuccess { (older, nextSnap) ->
                    oldestSnapshot = nextSnap
                    val visible = older.filter { !it.deletedFor.contains(myUid) }
                    _uiState.value = _uiState.value.copy(
                        olderMessages = (visible + _uiState.value.olderMessages).distinctBy { it.messageId },
                        isLoadingMore = false,
                        hasMoreOlder = older.isNotEmpty() && nextSnap != null
                    )
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoadingMore = false,
                        error = e.localizedMessage
                    )
                }
        }
    }

    fun onTypingChanged(text: String) {
        val chatId = _uiState.value.chatId
        if (chatId.isBlank() || _uiState.value.isBlocked) return
        typingJob?.cancel()
        if (text.isBlank()) {
            viewModelScope.launch { chatRepo.setTypingStatus(chatId, false) }
            return
        }
        typingJob = viewModelScope.launch {
            chatRepo.setTypingStatus(chatId, true)
            delay(4500L)
            chatRepo.setTypingStatus(chatId, false)
        }
    }

    fun setReplyTarget(message: ChatMessage?) {
        _uiState.value = _uiState.value.copy(replyingTo = message)
    }

    fun sendTextMessage(text: String) {
        val clean = text.trim()
        val state = _uiState.value
        val me = state.myProfile ?: return
        if (clean.isEmpty() || state.isBlocked) return

        val tempId = UUID.randomUUID().toString()
        val reply = state.replyingTo
        _uiState.value = state.copy(replyingTo = null)

        viewModelScope.launch {
            chatRepo.sendMessage(
                chatId = state.chatId,
                peerUid = state.peerUid,
                senderProfile = me,
                type = "text",
                text = clean,
                replyTo = reply,
                customMessageId = tempId
            ).onFailure { e ->
                val failed = ChatMessage(
                    messageId = tempId,
                    senderId = me.uid,
                    senderName = me.displayName,
                    type = "text",
                    text = clean,
                    localStatusOverride = "failed",
                    localError = e.localizedMessage,
                    createdAt = Timestamp.now()
                )
                _uiState.value = _uiState.value.copy(
                    failedMessages = _uiState.value.failedMessages + failed,
                    error = e.localizedMessage ?: "Failed to send message"
                )
            }
        }
    }

    fun sendImageMessage(imageUri: Uri, caption: String = "") {
        val state = _uiState.value
        val me = state.myProfile ?: return
        if (state.isBlocked) return
        val tempId = UUID.randomUUID().toString()

        viewModelScope.launch {
            storageRepo.uploadChatImage(state.chatId, me.uid, imageUri, isGroup = false)
                .collect { progress ->
                    when (progress) {
                        is UploadProgress.InProgress -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress + (tempId to progress.fraction)
                            )
                        }
                        is UploadProgress.Success -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress - tempId
                            )
                            chatRepo.sendMessage(
                                chatId = state.chatId,
                                peerUid = state.peerUid,
                                senderProfile = me,
                                type = "image",
                                text = caption,
                                mediaUrl = progress.downloadUrl,
                                customMessageId = tempId
                            ).onFailure { e ->
                                _uiState.value = _uiState.value.copy(error = e.localizedMessage)
                            }
                        }
                        is UploadProgress.Failure -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress - tempId,
                                error = progress.message
                            )
                        }
                    }
                }
        }
    }

    fun startRecording() = audioRecorder.startRecording()

    fun stopRecordingForPreview() {
        val result = audioRecorder.stopAndKeep()
        _uiState.value = _uiState.value.copy(previewAudio = result)
    }

    fun discardRecording() {
        audioRecorder.cancelAndDiscard()
        _uiState.value.previewAudio?.first?.delete()
        _uiState.value = _uiState.value.copy(previewAudio = null)
    }

    fun sendVoicePreview() {
        val preview = _uiState.value.previewAudio ?: return
        val state = _uiState.value
        val me = state.myProfile ?: return
        val (file, durationMs) = preview
        _uiState.value = state.copy(previewAudio = null)
        val tempId = UUID.randomUUID().toString()

        viewModelScope.launch {
            storageRepo.uploadVoiceNote(state.chatId, me.uid, file, isGroup = false)
                .collect { progress ->
                    when (progress) {
                        is UploadProgress.InProgress -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress + (tempId to progress.fraction)
                            )
                        }
                        is UploadProgress.Success -> {
                            file.delete()
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress - tempId
                            )
                            chatRepo.sendMessage(
                                chatId = state.chatId,
                                peerUid = state.peerUid,
                                senderProfile = me,
                                type = "audio",
                                text = "",
                                mediaUrl = progress.downloadUrl,
                                mediaDurationMs = durationMs,
                                customMessageId = tempId
                            )
                        }
                        is UploadProgress.Failure -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress - tempId,
                                error = progress.message
                            )
                        }
                    }
                }
        }
    }

    fun retryFailedMessage(failed: ChatMessage) {
        _uiState.value = _uiState.value.copy(
            failedMessages = _uiState.value.failedMessages.filterNot { it.messageId == failed.messageId }
        )
        sendTextMessage(failed.text)
    }

    fun togglePlayVoice(message: ChatMessage) {
        audioPlayer.togglePlay(message.messageId, message.mediaUrl, message.mediaDurationMs)
    }

    fun seekVoice(messageId: String, positionMs: Long) {
        audioPlayer.seekTo(messageId, positionMs)
    }

    fun deleteForMe(messageId: String) {
        viewModelScope.launch {
            chatRepo.deleteMessageForMe(_uiState.value.chatId, messageId)
        }
    }

    fun deleteForEveryone(messageId: String) {
        viewModelScope.launch {
            chatRepo.deleteMessageForEveryone(_uiState.value.chatId, messageId)
        }
    }

    fun forwardMessageToChat(targetPeerUid: String, message: ChatMessage, onDone: () -> Unit) {
        val me = _uiState.value.myProfile ?: return
        viewModelScope.launch {
            chatRepo.getOrCreatePrivateChat(targetPeerUid).onSuccess { targetChatId ->
                chatRepo.sendMessage(
                    chatId = targetChatId,
                    peerUid = targetPeerUid,
                    senderProfile = me,
                    type = message.type,
                    text = message.text,
                    mediaUrl = message.mediaUrl,
                    mediaDurationMs = message.mediaDurationMs,
                    isForwarded = true
                )
                onDone()
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
        audioRecorder.cancelAndDiscard()
    }
}
