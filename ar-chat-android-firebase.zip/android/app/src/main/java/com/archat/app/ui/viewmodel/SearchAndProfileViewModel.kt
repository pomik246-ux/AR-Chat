package com.archat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.data.model.UserContact
import com.archat.app.data.model.UserProfile
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SearchAndProfileViewModel : ViewModel() {
    private val userRepo = FirebaseServiceLocator.userRepository
    private val chatRepo = FirebaseServiceLocator.chatRepository
    private val groupRepo = FirebaseServiceLocator.groupRepository

    private val _searchResults = MutableStateFlow<List<UserProfile>>(emptyList())
    val searchResults: StateFlow<List<UserProfile>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    val contacts: StateFlow<List<UserContact>> = userRepo.observeContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var searchJob: Job? = null

    init {
        searchUsers("")
    }

    fun searchUsers(query: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(250L)
            _isSearching.value = true
            userRepo.searchUsers(query)
                .onSuccess {
                    _searchResults.value = it
                    _isSearching.value = false
                }
                .onFailure {
                    _error.value = it.localizedMessage
                    _isSearching.value = false
                }
        }
    }

    fun startPrivateChat(peerUid: String, onChatReady: (String) -> Unit) {
        viewModelScope.launch {
            if (userRepo.isBlockedEitherWay(peerUid)) {
                _error.value = "Messaging is unavailable because one of you has blocked the other."
                return@launch
            }
            chatRepo.getOrCreatePrivateChat(peerUid)
                .onSuccess { chatId -> onChatReady(chatId) }
                .onFailure { _error.value = it.localizedMessage }
        }
    }

    fun addContact(user: UserProfile, favorite: Boolean = false) {
        viewModelScope.launch {
            userRepo.addContact(user, favorite)
                .onFailure { _error.value = it.localizedMessage }
        }
    }

    fun toggleFavorite(contactUid: String, isFavorite: Boolean) {
        viewModelScope.launch {
            userRepo.toggleFavoriteContact(contactUid, isFavorite)
        }
    }

    fun removeContact(contactUid: String) {
        viewModelScope.launch {
            userRepo.removeContact(contactUid)
        }
    }

    fun blockUser(user: UserProfile) {
        viewModelScope.launch {
            userRepo.blockUser(user)
                .onFailure { _error.value = it.localizedMessage }
        }
    }

    fun unblockUser(uid: String) {
        viewModelScope.launch {
            userRepo.unblockUser(uid)
        }
    }

    fun reportUser(reportedUid: String, reason: String, details: String, onDone: () -> Unit) {
        viewModelScope.launch {
            userRepo.reportUser(reportedUid, reason, details)
                .onSuccess { onDone() }
                .onFailure { _error.value = it.localizedMessage }
        }
    }

    fun createGroup(
        name: String,
        description: String,
        photoUri: Uri?,
        selectedUsers: List<UserProfile>,
        onCreated: (String) -> Unit
    ) {
        val myUid = userRepo.currentUid() ?: return
        viewModelScope.launch {
            val creator = userRepo.getUserProfile(myUid).getOrNull() ?: return@launch
            groupRepo.createGroup(name, description, photoUri, creator, selectedUsers)
                .onSuccess { onCreated(it) }
                .onFailure { _error.value = it.localizedMessage }
        }
    }

    fun clearError() {
        _error.value = null
    }
}
