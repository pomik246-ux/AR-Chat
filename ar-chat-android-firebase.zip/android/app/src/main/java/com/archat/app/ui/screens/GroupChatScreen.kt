package com.archat.app.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.ui.components.ChatInputBar
import com.archat.app.ui.components.EmptyState
import com.archat.app.ui.components.MessageBubble
import com.archat.app.ui.components.UserAvatar
import com.archat.app.ui.theme.ARGreen
import com.archat.app.ui.viewmodel.GroupChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupChatScreen(
    groupId: String,
    onNavigateBack: () -> Unit,
    onOpenGroupDetails: (String) -> Unit,
    onOpenImageViewer: (String) -> Unit,
    viewModel: GroupChatViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val recordingState by viewModel.recordingState.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val snackbarHostState = remember { SnackbarHostState() }
    val myUid = FirebaseServiceLocator.auth.currentUser?.uid ?: ""

    LaunchedEffect(groupId) {
        viewModel.loadGroup(groupId)
    }

    val allMessages = remember(uiState.olderMessages, uiState.messages) {
        (uiState.olderMessages + uiState.messages).distinctBy { it.messageId }
    }

    LaunchedEffect(allMessages.size) {
        if (allMessages.isNotEmpty()) {
            listState.animateScrollToItem(allMessages.lastIndex)
        }
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.sendImageMessage(uri)
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.startRecording()
    }

    val group = uiState.group
    val activeTypers = group?.typingUsers?.filter { (uid, ts) ->
        uid != myUid && ts != null && (System.currentTimeMillis() - ts.toDate().time) < 6000L
    }?.keys ?: emptySet()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenGroupDetails(groupId) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(
                            photoUrl = group?.photoUrl ?: "",
                            displayName = group?.name ?: "Group",
                            size = 38.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = group?.name ?: "Group",
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (activeTypers.isNotEmpty()) "Someone is typing..." else "${group?.memberIds?.size ?: 0} members",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (activeTypers.isNotEmpty()) ARGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { onOpenGroupDetails(groupId) }) {
                        Icon(Icons.Filled.Info, contentDescription = "Group details")
                    }
                }
            )
        },
        bottomBar = {
            ChatInputBar(
                text = inputText,
                onTextChange = {
                    inputText = it
                    viewModel.onTypingChanged(it)
                },
                replyingTo = uiState.replyingTo,
                onCancelReply = { viewModel.setReplyTarget(null) },
                recordingState = recordingState,
                previewAudio = uiState.previewAudio,
                onPickImage = { imagePicker.launch("image/*") },
                onStartRecording = {
                    val granted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    if (granted) viewModel.startRecording()
                    else audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                onStopRecording = { viewModel.stopRecordingForPreview() },
                onDiscardRecording = { viewModel.discardRecording() },
                onSendText = {
                    val msg = inputText
                    inputText = ""
                    viewModel.onTypingChanged("")
                    viewModel.sendTextMessage(msg)
                },
                onSendVoicePreview = { viewModel.sendVoicePreview() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (allMessages.isEmpty()) {
                EmptyState(
                    icon = Icons.Outlined.Groups,
                    title = group?.name ?: "Group Chat",
                    subtitle = "Messages sent to this group appear instantly for all members."
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (uiState.hasMoreOlder && allMessages.size >= 30) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                TextButton(
                                    onClick = { viewModel.loadOlderMessages() },
                                    enabled = !uiState.isLoadingMore
                                ) {
                                    Text(if (uiState.isLoadingMore) "Loading older..." else "Load older messages")
                                }
                            }
                        }
                    }

                    items(allMessages, key = { it.messageId }) { msg ->
                        MessageBubble(
                            message = msg,
                            isOutgoing = msg.senderId == myUid,
                            showSenderName = true,
                            playbackState = playbackState,
                            uploadFraction = uiState.uploadProgress[msg.messageId],
                            onImageClick = onOpenImageViewer,
                            onToggleVoicePlay = { viewModel.togglePlayVoice(msg) },
                            onSeekVoice = { pos -> viewModel.seekVoice(msg.messageId, pos) },
                            onReply = { viewModel.setReplyTarget(msg) },
                            onForward = {},
                            onCopy = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("AR Chat", msg.text))
                            },
                            onDeleteForMe = {},
                            onDeleteForEveryone = { viewModel.deleteForEveryone(msg.messageId) },
                            onRetry = {}
                        )
                    }
                }
            }
        }
    }
}
