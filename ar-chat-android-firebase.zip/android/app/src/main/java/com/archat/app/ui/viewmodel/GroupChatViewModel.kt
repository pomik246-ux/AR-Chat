package com.archat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.data.model.ChatMessage
import com.archat.app.data.model.GroupChat
import com.archat.app.data.model.GroupMember
import com.archat.app.data.model.UserProfile
import com.archat.app.data.repository.UploadProgress
import com.archat.app.utils.AudioPlaybackState
import com.archat.app.utils.RecordingState
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class GroupChatUiState(
    val groupId: String = "",
    val group: GroupChat? = null,
    val members: List<GroupMember> = emptyList(),
    val myProfile: UserProfile? = null,
    val messages: List<ChatMessage> = emptyList(),
    val olderMessages: List<ChatMessage> = emptyList(),
    val replyingTo: ChatMessage? = null,
    val previewAudio: Pair<File, Long>? = null,
    val uploadProgress: Map<String, Float> = emptyMap(),
    val isLoadingMore: Boolean = false,
    val hasMoreOlder: Boolean = true,
    val error: String? = null
)

class GroupChatViewModel : ViewModel() {
    private val groupRepo = FirebaseServiceLocator.groupRepository
    private val userRepo = FirebaseServiceLocator.userRepository
    private val storageRepo = FirebaseServiceLocator.storageRepository
    private val audioRecorder = FirebaseServiceLocator.audioRecorder
    private val audioPlayer = FirebaseServiceLocator.audioPlayer

    private val _uiState = MutableStateFlow(GroupChatUiState())
    val uiState: StateFlow<GroupChatUiState> = _uiState.asStateFlow()

    val recordingState: StateFlow<RecordingState> = audioRecorder.state
    val playbackState: StateFlow<AudioPlaybackState> = audioPlayer.playbackState

    private var oldestSnapshot: DocumentSnapshot? = null
    private var typingJob: Job? = null
    private var loadedGroupId: String? = null

    fun loadGroup(groupId: String) {
        if (loadedGroupId == groupId) return
        loadedGroupId = groupId
        val myUid = groupRepo.currentUid() ?: return

        _uiState.value = _uiState.value.copy(groupId = groupId)

        viewModelScope.launch {
            userRepo.observeUserProfile(myUid).collect { me ->
                _uiState.value = _uiState.value.copy(myProfile = me)
            }
        }
        viewModelScope.launch {
            groupRepo.observeGroup(groupId).collect { grp ->
                _uiState.value = _uiState.value.copy(group = grp)
            }
        }
        viewModelScope.launch {
            groupRepo.observeGroupMembers(groupId).collect { list ->
                _uiState.value = _uiState.value.copy(members = list)
            }
        }
        viewModelScope.launch {
            groupRepo.observeGroupMessages(groupId).collect { (msgs, oldest) ->
                if (oldestSnapshot == null) oldestSnapshot = oldest
                val visible = msgs.filter { !it.deletedFor.contains(myUid) }
                _uiState.value = _uiState.value.copy(messages = visible)
                groupRepo.clearGroupUnread(groupId)
            }
        }
    }

    fun loadOlderMessages() {
        val snap = oldestSnapshot ?: return
        if (_uiState.value.isLoadingMore || !_uiState.value.hasMoreOlder) return
        val myUid = groupRepo.currentUid() ?: return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingMore = true)
            groupRepo.loadOlderGroupMessages(_uiState.value.groupId, snap)
                .onSuccess { (older, nextSnap) ->
                    oldestSnapshot = nextSnap
                    val visible = older.filter { !it.deletedFor.contains(myUid) }
                    _uiState.value = _uiState.value.copy(
                        olderMessages = (visible + _uiState.value.olderMessages).distinctBy { it.messageId },
                        isLoadingMore = false,
                        hasMoreOlder = older.isNotEmpty() && nextSnap != null
                    )
                }
                .onFailure {
                    _uiState.value = _uiState.value.copy(isLoadingMore = false)
                }
        }
    }

    fun onTypingChanged(text: String) {
        val groupId = _uiState.value.groupId
        if (groupId.isBlank()) return
        typingJob?.cancel()
        if (text.isBlank()) {
            viewModelScope.launch { groupRepo.setGroupTyping(groupId, false) }
            return
        }
        typingJob = viewModelScope.launch {
            groupRepo.setGroupTyping(groupId, true)
            delay(4500L)
            groupRepo.setGroupTyping(groupId, false)
        }
    }

    fun setReplyTarget(message: ChatMessage?) {
        _uiState.value = _uiState.value.copy(replyingTo = message)
    }

    fun sendTextMessage(text: String) {
        val clean = text.trim()
        val state = _uiState.value
        val me = state.myProfile ?: return
        val memberIds = state.group?.memberIds ?: return
        if (clean.isEmpty()) return
        val reply = state.replyingTo
        _uiState.value = state.copy(replyingTo = null)

        viewModelScope.launch {
            groupRepo.sendGroupMessage(
                groupId = state.groupId,
                sender = me,
                memberIds = memberIds,
                type = "text",
                text = clean,
                replyTo = reply
            ).onFailure { e ->
                _uiState.value = _uiState.value.copy(error = e.localizedMessage)
            }
        }
    }

    fun sendImageMessage(imageUri: Uri) {
        val state = _uiState.value
        val me = state.myProfile ?: return
        val memberIds = state.group?.memberIds ?: return
        val tempId = UUID.randomUUID().toString()

        viewModelScope.launch {
            storageRepo.uploadChatImage(state.groupId, me.uid, imageUri, isGroup = true)
                .collect { progress ->
                    when (progress) {
                        is UploadProgress.InProgress -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress + (tempId to progress.fraction)
                            )
                        }
                        is UploadProgress.Success -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress - tempId
                            )
                            groupRepo.sendGroupMessage(
                                groupId = state.groupId,
                                sender = me,
                                memberIds = memberIds,
                                type = "image",
                                text = "",
                                mediaUrl = progress.downloadUrl,
                                customMessageId = tempId
                            )
                        }
                        is UploadProgress.Failure -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress - tempId,
                                error = progress.message
                            )
                        }
                    }
                }
        }
    }

    fun startRecording() = audioRecorder.startRecording()

    fun stopRecordingForPreview() {
        _uiState.value = _uiState.value.copy(previewAudio = audioRecorder.stopAndKeep())
    }

    fun discardRecording() {
        audioRecorder.cancelAndDiscard()
        _uiState.value.previewAudio?.first?.delete()
        _uiState.value = _uiState.value.copy(previewAudio = null)
    }

    fun sendVoicePreview() {
        val preview = _uiState.value.previewAudio ?: return
        val state = _uiState.value
        val me = state.myProfile ?: return
        val memberIds = state.group?.memberIds ?: return
        val (file, durationMs) = preview
        _uiState.value = state.copy(previewAudio = null)
        val tempId = UUID.randomUUID().toString()

        viewModelScope.launch {
            storageRepo.uploadVoiceNote(state.groupId, me.uid, file, isGroup = true)
                .collect { progress ->
                    when (progress) {
                        is UploadProgress.InProgress -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress + (tempId to progress.fraction)
                            )
                        }
                        is UploadProgress.Success -> {
                            file.delete()
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress - tempId
                            )
                            groupRepo.sendGroupMessage(
                                groupId = state.groupId,
                                sender = me,
                                memberIds = memberIds,
                                type = "audio",
                                text = "",
                                mediaUrl = progress.downloadUrl,
                                mediaDurationMs = durationMs,
                                customMessageId = tempId
                            )
                        }
                        is UploadProgress.Failure -> {
                            _uiState.value = _uiState.value.copy(
                                uploadProgress = _uiState.value.uploadProgress - tempId,
                                error = progress.message
                            )
                        }
                    }
                }
        }
    }

    fun togglePlayVoice(message: ChatMessage) {
        audioPlayer.togglePlay(message.messageId, message.mediaUrl, message.mediaDurationMs)
    }

    fun seekVoice(messageId: String, positionMs: Long) {
        audioPlayer.seekTo(messageId, positionMs)
    }

    fun deleteForEveryone(messageId: String) {
        viewModelScope.launch {
            groupRepo.deleteGroupMessageForEveryone(_uiState.value.groupId, messageId)
        }
    }

    fun updateGroupInfo(name: String, description: String, photoUri: Uri?) {
        viewModelScope.launch {
            groupRepo.updateGroupInfo(_uiState.value.groupId, name, description, photoUri)
                .onFailure { _uiState.value = _uiState.value.copy(error = it.localizedMessage) }
        }
    }

    fun addMember(user: UserProfile) {
        viewModelScope.launch {
            groupRepo.addGroupMember(_uiState.value.groupId, user)
                .onFailure { _uiState.value = _uiState.value.copy(error = it.localizedMessage) }
        }
    }

    fun removeMember(targetUid: String) {
        viewModelScope.launch {
            groupRepo.removeGroupMember(_uiState.value.groupId, targetUid)
                .onFailure { _uiState.value = _uiState.value.copy(error = it.localizedMessage) }
        }
    }

    fun toggleAdminRole(targetUid: String, makeAdmin: Boolean) {
        viewModelScope.launch {
            groupRepo.setMemberAdminRole(_uiState.value.groupId, targetUid, makeAdmin)
                .onFailure { _uiState.value = _uiState.value.copy(error = it.localizedMessage) }
        }
    }

    fun toggleMute(muted: Boolean) {
        viewModelScope.launch {
            groupRepo.toggleMuteGroup(_uiState.value.groupId, muted)
        }
    }

    fun leaveGroup(onLeft: () -> Unit) {
        viewModelScope.launch {
            groupRepo.leaveGroup(_uiState.value.groupId)
                .onSuccess { onLeft() }
                .onFailure { _uiState.value = _uiState.value.copy(error = it.localizedMessage) }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
        audioRecorder.cancelAndDiscard()
    }
}
