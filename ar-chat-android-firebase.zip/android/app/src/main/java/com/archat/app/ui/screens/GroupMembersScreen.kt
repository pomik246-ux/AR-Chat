package com.archat.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.ui.components.UserAvatar
import com.archat.app.ui.theme.ARGreen
import com.archat.app.ui.theme.DangerRed
import com.archat.app.ui.viewmodel.GroupChatViewModel
import com.archat.app.ui.viewmodel.SearchAndProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupMembersScreen(
    groupId: String,
    searchViewModel: SearchAndProfileViewModel,
    onNavigateBack: () -> Unit,
    onOpenUserProfile: (String) -> Unit,
    viewModel: GroupChatViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val allUsers by searchViewModel.searchResults.collectAsStateWithLifecycle()
    val myUid = FirebaseServiceLocator.auth.currentUser?.uid ?: ""
    val isAdmin = uiState.group?.adminIds?.contains(myUid) == true
    var showAddDialog by remember { mutableStateOf(false) }

    LaunchedEffect(groupId) {
        viewModel.loadGroup(groupId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Group Members (${uiState.members.size})") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (isAdmin) {
                        IconButton(onClick = { showAddDialog = true }) {
                            Icon(Icons.Filled.PersonAdd, contentDescription = "Add member")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            items(uiState.members, key = { it.uid }) { member ->
                var menuExpanded by remember { mutableStateOf(false) }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (member.uid != myUid) onOpenUserProfile(member.uid)
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(photoUrl = member.photoUrl, displayName = member.displayName, size = 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (member.uid == myUid) "${member.displayName} (You)" else member.displayName,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "@${member.username}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (member.role == "admin") {
                        Text(
                            text = "Admin",
                            style = MaterialTheme.typography.labelMedium,
                            color = ARGreen,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }
                    if (isAdmin && member.uid != myUid) {
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "Manage member")
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Text(if (member.role == "admin") "Dismiss as admin" else "Make group admin")
                                },
                                onClick = {
                                    menuExpanded = false
                                    viewModel.toggleAdminRole(member.uid, member.role != "admin")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Remove from group", color = DangerRed) },
                                onClick = {
                                    menuExpanded = false
                                    viewModel.removeMember(member.uid)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        val currentMemberIds = uiState.group?.memberIds ?: emptyList()
        val candidates = allUsers.filter { !currentMemberIds.contains(it.uid) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Participant") },
            text = {
                if (candidates.isEmpty()) {
                    Text("All discovered users are already in this group.")
                } else {
                    LazyColumn {
                        items(candidates, key = { it.uid }) { candidate ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.addMember(candidate)
                                        showAddDialog = false
                                    }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(photoUrl = candidate.photoUrl, displayName = candidate.displayName, size = 38.dp)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(candidate.displayName, fontWeight = FontWeight.SemiBold)
                                    Text("@${candidate.username}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Close") }
            }
        )
    }
}
