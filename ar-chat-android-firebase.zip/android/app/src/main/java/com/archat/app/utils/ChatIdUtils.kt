package com.archat.app.utils

object ChatIdUtils {
    /**
     * Generates a deterministic sorted private chat ID from two UIDs
     * so duplicate 1-on-1 conversations between the same two users cannot exist.
     */
    fun deterministicChatId(uidA: String, uidB: String): String {
        require(uidA.isNotBlank() && uidB.isNotBlank() && uidA != uidB) {
            "Two distinct non-blank UIDs are required"
        }
        return if (uidA < uidB) "${uidA}_${uidB}" else "${uidB}_${uidA}"
    }

    fun peerUidFromChat(participants: List<String>, myUid: String): String? {
        return participants.firstOrNull { it != myUid }
    }
}
