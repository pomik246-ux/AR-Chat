package com.archat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.data.model.BlockedUser
import com.archat.app.data.model.UserPrivateInfo
import com.archat.app.data.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel : ViewModel() {
    private val userRepo = FirebaseServiceLocator.userRepository
    private val authRepo = FirebaseServiceLocator.authRepository

    private val uidFlow = MutableStateFlow(userRepo.currentUid())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val myProfile: StateFlow<UserProfile?> = uidFlow
        .flatMapLatest { uid ->
            if (uid.isNullOrBlank()) flowOf(null) else userRepo.observeUserProfile(uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val privateInfo: StateFlow<UserPrivateInfo?> = uidFlow
        .flatMapLatest { uid ->
            if (uid.isNullOrBlank()) flowOf(null) else userRepo.observePrivateInfo(uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val blockedUsers: StateFlow<List<BlockedUser>> = userRepo.observeBlockedUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isDarkModeOverride = MutableStateFlow<Boolean?>(null)
    val isDarkModeOverride: StateFlow<Boolean?> = _isDarkModeOverride.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    fun refreshUid() {
        uidFlow.value = userRepo.currentUid()
    }

    fun setDarkMode(dark: Boolean?) {
        _isDarkModeOverride.value = dark
    }

    fun saveProfile(displayName: String, bio: String, photoUri: Uri?, onDone: () -> Unit) {
        viewModelScope.launch {
            _isSaving.value = true
            userRepo.updateProfile(displayName, bio, photoUri)
                .onSuccess {
                    _isSaving.value = false
                    _statusMessage.value = "Profile updated"
                    onDone()
                }
                .onFailure {
                    _isSaving.value = false
                    _statusMessage.value = it.localizedMessage ?: "Update failed"
                }
        }
    }

    fun savePrivacy(
        showLastSeen: String,
        showOnline: Boolean,
        showPhoto: String,
        whoCanMessage: String
    ) {
        viewModelScope.launch {
            userRepo.updatePrivacySettings(showLastSeen, showOnline, showPhoto, whoCanMessage)
                .onSuccess { _statusMessage.value = "Privacy settings saved" }
                .onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun saveNotifications(
        notifyPrivate: Boolean,
        notifyGroup: Boolean,
        notifyInvites: Boolean,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean,
        showPreview: Boolean
    ) {
        viewModelScope.launch {
            userRepo.updateNotificationPreferences(
                notifyPrivate, notifyGroup, notifyInvites,
                soundEnabled, vibrationEnabled, showPreview
            ).onFailure { _statusMessage.value = it.localizedMessage }
        }
    }

    fun unblockUser(uid: String) {
        viewModelScope.launch {
            userRepo.unblockUser(uid)
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepo.logout()
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
