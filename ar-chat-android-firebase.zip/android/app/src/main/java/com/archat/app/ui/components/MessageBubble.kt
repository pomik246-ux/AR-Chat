package com.archat.app.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Forward
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.archat.app.data.model.ChatMessage
import com.archat.app.ui.theme.ARGreen
import com.archat.app.ui.theme.DangerRed
import com.archat.app.ui.theme.IncomingBubbleDark
import com.archat.app.ui.theme.IncomingBubbleLight
import com.archat.app.ui.theme.OutgoingBubbleDark
import com.archat.app.ui.theme.OutgoingBubbleLight
import com.archat.app.ui.theme.TickReadColor
import com.archat.app.utils.AudioPlaybackState
import com.archat.app.utils.DateTimeUtils

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    message: ChatMessage,
    isOutgoing: Boolean,
    showSenderName: Boolean,
    playbackState: AudioPlaybackState,
    uploadFraction: Float? = null,
    onImageClick: (String) -> Unit,
    onToggleVoicePlay: () -> Unit,
    onSeekVoice: (Long) -> Unit,
    onReply: () -> Unit,
    onForward: () -> Unit,
    onCopy: () -> Unit,
    onDeleteForMe: () -> Unit,
    onDeleteForEveryone: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val darkTheme = isSystemInDarkTheme()

    val bubbleColor = when {
        isOutgoing -> if (darkTheme) OutgoingBubbleDark else OutgoingBubbleLight
        else -> if (darkTheme) IncomingBubbleDark else IncomingBubbleLight
    }
    val textColor = if (isOutgoing) Color.White else MaterialTheme.colorScheme.onSurface
    val metaColor = if (isOutgoing) Color.White.copy(alpha = 0.78f) else MaterialTheme.colorScheme.onSurfaceVariant

    val bubbleShape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = if (isOutgoing) 18.dp else 4.dp,
        bottomEnd = if (isOutgoing) 4.dp else 18.dp
    )

    val effectiveStatus = message.localStatusOverride ?: message.status

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalArrangement = if (isOutgoing) Arrangement.End else Arrangement.Start
    ) {
        Box {
            Column(
                modifier = Modifier
                    .widthIn(min = 84.dp, max = 296.dp)
                    .clip(bubbleShape)
                    .background(bubbleColor)
                    .combinedClickable(
                        onClick = {
                            if (message.type == "image" && message.mediaUrl.isNotBlank() && !message.isDeletedForEveryone) {
                                onImageClick(message.mediaUrl)
                            }
                        },
                        onLongClick = { menuExpanded = true }
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                if (showSenderName && !isOutgoing) {
                    Text(
                        text = message.senderName,
                        style = MaterialTheme.typography.labelMedium,
                        color = ARGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(2.dp))
                }

                if (message.isForwarded && !message.isDeletedForEveryone) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Forward,
                            contentDescription = null,
                            tint = metaColor,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Forwarded",
                            style = MaterialTheme.typography.labelSmall,
                            fontStyle = FontStyle.Italic,
                            color = metaColor
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                }

                if (message.replyToMessageId.isNotBlank() && !message.isDeletedForEveryone) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isOutgoing) Color.Black.copy(alpha = 0.16f)
                                else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                            )
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = message.replyToSenderName,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isOutgoing) Color.White else ARGreen,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = message.replyToText,
                            style = MaterialTheme.typography.bodySmall,
                            color = metaColor,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                }

                when {
                    message.isDeletedForEveryone -> {
                        Text(
                            text = "This message was deleted",
                            style = MaterialTheme.typography.bodyMedium,
                            fontStyle = FontStyle.Italic,
                            color = metaColor
                        )
                    }
                    message.type == "image" -> {
                        val imageModel = message.mediaUrl.ifBlank { message.localMediaUri }
                        if (!imageModel.isNullOrBlank()) {
                            AsyncImage(
                                model = imageModel,
                                contentDescription = "Photo message",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(190.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        if (message.mediaUrl.isNotBlank()) onImageClick(message.mediaUrl)
                                    }
                            )
                        }
                        if (uploadFraction != null && uploadFraction < 1f) {
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { uploadFraction },
                                modifier = Modifier.fillMaxWidth(),
                                color = Color.White,
                                trackColor = Color.White.copy(alpha = 0.3f)
                            )
                        }
                        if (message.text.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = message.text,
                                style = MaterialTheme.typography.bodyLarge,
                                color = textColor
                            )
                        }
                    }
                    message.type == "audio" -> {
                        VoiceMessagePlayback(
                            messageId = message.messageId,
                            mediaUrl = message.mediaUrl,
                            durationMs = message.mediaDurationMs,
                            playbackState = playbackState,
                            isOutgoing = isOutgoing,
                            onTogglePlay = onToggleVoicePlay,
                            onSeek = onSeekVoice
                        )
                        if (uploadFraction != null && uploadFraction < 1f) {
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { uploadFraction },
                                modifier = Modifier.fillMaxWidth(),
                                color = Color.White,
                                trackColor = Color.White.copy(alpha = 0.3f)
                            )
                        }
                    }
                    else -> {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor
                        )
                    }
                }

                Spacer(Modifier.height(4.dp))

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = DateTimeUtils.formatMessageTime(message.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = metaColor
                    )
                    if (isOutgoing && !message.isDeletedForEveryone) {
                        Spacer(Modifier.width(4.dp))
                        when (effectiveStatus) {
                            "sending" -> Icon(
                                imageVector = Icons.Outlined.Schedule,
                                contentDescription = "Sending",
                                tint = metaColor,
                                modifier = Modifier.size(14.dp)
                            )
                            "sent" -> Icon(
                                imageVector = Icons.Filled.Done,
                                contentDescription = "Sent",
                                tint = metaColor,
                                modifier = Modifier.size(15.dp)
                            )
                            "delivered" -> Icon(
                                imageVector = Icons.Filled.DoneAll,
                                contentDescription = "Delivered",
                                tint = metaColor,
                                modifier = Modifier.size(15.dp)
                            )
                            "read" -> Icon(
                                imageVector = Icons.Filled.DoneAll,
                                contentDescription = "Read",
                                tint = TickReadColor,
                                modifier = Modifier.size(15.dp)
                            )
                            "failed" -> IconButton(
                                onClick = onRetry,
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = "Retry send",
                                    tint = DangerRed,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                if (!message.isDeletedForEveryone) {
                    DropdownMenuItem(
                        text = { Text("Reply") },
                        onClick = {
                            menuExpanded = false
                            onReply()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Forward") },
                        onClick = {
                            menuExpanded = false
                            onForward()
                        }
                    )
                    if (message.text.isNotBlank()) {
                        DropdownMenuItem(
                            text = { Text("Copy text") },
                            onClick = {
                                menuExpanded = false
                                onCopy()
                            }
                        )
                    }
                }
                DropdownMenuItem(
                    text = { Text("Delete for me") },
                    onClick = {
                        menuExpanded = false
                        onDeleteForMe()
                    }
                )
                if (isOutgoing && !message.isDeletedForEveryone) {
                    DropdownMenuItem(
                        text = { Text("Delete for everyone", color = DangerRed) },
                        onClick = {
                            menuExpanded = false
                            onDeleteForEveryone()
                        }
                    )
                }
            }
        }
    }
}
