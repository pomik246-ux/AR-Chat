package com.archat.app.data.firebase

import android.Manifest
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.archat.app.ARChatApplication
import com.archat.app.MainActivity
import com.archat.app.R
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

class ARChatMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        CoroutineScope(Dispatchers.IO).launch {
            FirebaseServiceLocator.authRepository.saveFcmToken(token)
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val data = remoteMessage.data
        val chatType = data["chatType"] ?: "private"
        val chatId = data["chatId"] ?: ""
        val groupName = data["groupName"] ?: ""
        val senderName = data["senderName"] ?: remoteMessage.notification?.title ?: "AR Chat"
        val senderPhotoUrl = data["senderPhotoUrl"] ?: ""
        val title = remoteMessage.notification?.title ?: if (chatType == "group") groupName else senderName
        val body = remoteMessage.notification?.body ?: "New message"

        val channelId = when (chatType) {
            "group" -> ARChatApplication.CHANNEL_GROUP_MESSAGES
            "invite" -> ARChatApplication.CHANNEL_CHAT_INVITES
            else -> ARChatApplication.CHANNEL_PRIVATE_MESSAGES
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            action = "OPEN_CHAT_FROM_NOTIFICATION"
            putExtra(EXTRA_CHAT_TYPE, chatType)
            putExtra(EXTRA_CHAT_ID, chatId)
            putExtra(EXTRA_TITLE, title)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            chatId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val largeIcon = loadAvatarBitmap(senderPhotoUrl)

        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon)
        }

        NotificationManagerCompat.from(this).notify(chatId.hashCode(), builder.build())
    }

    private fun loadAvatarBitmap(urlStr: String): Bitmap? {
        if (urlStr.isBlank() || !urlStr.startsWith("https://")) return null
        return try {
            val conn = URL(urlStr).openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.readTimeout = 3000
            conn.doInput = true
            conn.connect()
            conn.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        const val EXTRA_CHAT_TYPE = "extra_chat_type"
        const val EXTRA_CHAT_ID = "extra_chat_id"
        const val EXTRA_TITLE = "extra_title"
    }
}
