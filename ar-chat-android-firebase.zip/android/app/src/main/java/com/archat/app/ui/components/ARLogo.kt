package com.archat.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archat.app.ui.theme.ARGreen
import com.archat.app.ui.theme.ARGreenDark

@Composable
fun ARLogo(
    size: Dp = 64.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(
                RoundedCornerShape(
                    topStart = size * 0.32f,
                    topEnd = size * 0.32f,
                    bottomEnd = size * 0.32f,
                    bottomStart = size * 0.08f
                )
            )
            .background(
                Brush.linearGradient(
                    colors = listOf(ARGreen, ARGreenDark)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "AR",
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = (size.value * 0.38f).sp,
            letterSpacing = (-0.5).sp
        )
    }
}
