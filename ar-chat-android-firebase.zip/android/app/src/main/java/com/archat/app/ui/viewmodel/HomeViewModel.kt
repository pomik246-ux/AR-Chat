package com.archat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.archat.app.data.firebase.FirebaseServiceLocator
import com.archat.app.data.model.GroupChat
import com.archat.app.data.model.PrivateChat
import com.archat.app.data.model.UserProfile
import com.archat.app.utils.ChatIdUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class ConversationItem(open val sortTimeMs: Long) {
    data class PrivateItem(
        val chat: PrivateChat,
        val peer: UserProfile?,
        val unreadCount: Int,
        val isPeerTyping: Boolean,
        override val sortTimeMs: Long
    ) : ConversationItem(sortTimeMs)

    data class GroupItem(
        val group: GroupChat,
        val unreadCount: Int,
        override val sortTimeMs: Long
    ) : ConversationItem(sortTimeMs)
}

class HomeViewModel : ViewModel() {
    private val chatRepo = FirebaseServiceLocator.chatRepository
    private val groupRepo = FirebaseServiceLocator.groupRepository
    private val userRepo = FirebaseServiceLocator.userRepository

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _peerCache = MutableStateFlow<Map<String, UserProfile>>(emptyMap())

    val isOffline: StateFlow<Boolean> = FirebaseServiceLocator.networkMonitor.isOnline
        .let { flow ->
            combine(flow) { values -> !values[0] }
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
        }

    val conversations: StateFlow<List<ConversationItem>> = combine(
        chatRepo.observeMyPrivateChats(),
        groupRepo.observeMyGroups(),
        _peerCache,
        _searchQuery
    ) { chats, groups, peers, query ->
        val myUid = chatRepo.currentUid() ?: ""

        // Fetch any missing peer profiles & mark delivered
        val missingUids = chats.mapNotNull { ChatIdUtils.peerUidFromChat(it.participants, myUid) }
            .filter { !peers.containsKey(it) }
            .distinct()
        if (missingUids.isNotEmpty()) {
            fetchPeers(missingUids)
        }
        viewModelScope.launch { chatRepo.markIncomingChatsDelivered(chats) }

        val privateItems = chats.map { chat ->
            val peerUid = ChatIdUtils.peerUidFromChat(chat.participants, myUid)
            val peer = peerUid?.let { peers[it] }
            val unread = (chat.unreadCounts[myUid] ?: 0L).toInt()
            val typingTs = peerUid?.let { chat.typingUsers[it] }
            val isTyping = typingTs != null && (System.currentTimeMillis() - typingTs.toDate().time) < 6000L
            ConversationItem.PrivateItem(
                chat = chat,
                peer = peer,
                unreadCount = unread,
                isPeerTyping = isTyping,
                sortTimeMs = chat.lastMessageAt?.toDate()?.time ?: chat.createdAt?.toDate()?.time ?: 0L
            )
        }

        val groupItems = groups.map { grp ->
            val unread = (grp.unreadCounts[myUid] ?: 0L).toInt()
            ConversationItem.GroupItem(
                group = grp,
                unreadCount = unread,
                sortTimeMs = grp.lastMessageAt?.toDate()?.time ?: grp.createdAt?.toDate()?.time ?: 0L
            )
        }

        val all = (privateItems + groupItems).sortedByDescending { it.sortTimeMs }
        val q = query.trim().lowercase()
        if (q.isEmpty()) all
        else all.filter { item ->
            when (item) {
                is ConversationItem.PrivateItem ->
                    (item.peer?.displayName?.lowercase()?.contains(q) == true) ||
                        (item.peer?.username?.lowercase()?.contains(q) == true) ||
                        item.chat.lastMessageText.lowercase().contains(q)
                is ConversationItem.GroupItem ->
                    item.group.name.lowercase().contains(q) ||
                        item.group.lastMessageText.lowercase().contains(q)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    private fun fetchPeers(uids: List<String>) {
        viewModelScope.launch {
            val loaded = mutableMapOf<String, UserProfile>()
            uids.forEach { uid ->
                userRepo.getUserProfile(uid).getOrNull()?.let { loaded[uid] = it }
            }
            if (loaded.isNotEmpty()) {
                _peerCache.value = _peerCache.value + loaded
            }
        }
    }
}
