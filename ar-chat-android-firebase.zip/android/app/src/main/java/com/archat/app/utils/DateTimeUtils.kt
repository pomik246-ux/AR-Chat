package com.archat.app.utils

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateTimeUtils {
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("MMM d", Locale.getDefault())
    private val fullDateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())

    fun formatMessageTime(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: return ""
        return timeFormat.format(date)
    }

    fun formatChatListTime(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: return ""
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply { time = date }

        return when {
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == target.get(Calendar.DAY_OF_YEAR) -> {
                timeFormat.format(date)
            }
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) - target.get(Calendar.DAY_OF_YEAR) == 1 -> {
                "Yesterday"
            }
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) -> {
                dateFormat.format(date)
            }
            else -> fullDateFormat.format(date)
        }
    }

    fun formatLastSeen(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: return "Offline"
        val diffMs = System.currentTimeMillis() - date.time
        val diffMin = diffMs / 60_000
        return when {
            diffMin < 1 -> "Last seen just now"
            diffMin < 60 -> "Last seen ${diffMin}m ago"
            else -> "Last seen ${formatChatListTime(timestamp)} at ${timeFormat.format(date)}"
        }
    }

    fun formatDuration(durationMs: Long): String {
        val totalSeconds = (durationMs / 1000L).coerceAtLeast(0L)
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%d:%02d", minutes, seconds)
    }
}
