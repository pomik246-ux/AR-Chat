package com.archat.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.archat.app.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationSettingsScreen(
    settingsViewModel: SettingsViewModel,
    onNavigateBack: () -> Unit
) {
    val privateInfo by settingsViewModel.privateInfo.collectAsStateWithLifecycle()

    var notifyPrivate by remember { mutableStateOf(true) }
    var notifyGroup by remember { mutableStateOf(true) }
    var notifyInvites by remember { mutableStateOf(true) }
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }
    var showPreview by remember { mutableStateOf(true) }

    LaunchedEffect(privateInfo) {
        privateInfo?.let {
            notifyPrivate = it.notifyPrivateMessages
            notifyGroup = it.notifyGroupMessages
            notifyInvites = it.notifyChatInvites
            soundEnabled = it.soundEnabled
            vibrationEnabled = it.vibrationEnabled
            showPreview = it.showMessagePreview
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notifications") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            NotificationToggleRow(
                title = "Private Message Alerts",
                subtitle = "Push notifications for 1-on-1 messages",
                checked = notifyPrivate,
                onCheckedChange = { notifyPrivate = it }
            )
            HorizontalDivider()
            NotificationToggleRow(
                title = "Group Message Alerts",
                subtitle = "Push notifications for group chats",
                checked = notifyGroup,
                onCheckedChange = { notifyGroup = it }
            )
            HorizontalDivider()
            NotificationToggleRow(
                title = "Chat & Group Invites",
                subtitle = "Notify when added to a new group",
                checked = notifyInvites,
                onCheckedChange = { notifyInvites = it }
            )
            HorizontalDivider()
            NotificationToggleRow(
                title = "Message Previews",
                subtitle = "Show message text inside push notifications",
                checked = showPreview,
                onCheckedChange = { showPreview = it }
            )
            HorizontalDivider()
            NotificationToggleRow(
                title = "Notification Sound",
                subtitle = "Play alert tone for incoming messages",
                checked = soundEnabled,
                onCheckedChange = { soundEnabled = it }
            )
            HorizontalDivider()
            NotificationToggleRow(
                title = "Vibration",
                subtitle = "Vibrate on new push notifications",
                checked = vibrationEnabled,
                onCheckedChange = { vibrationEnabled = it }
            )

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    settingsViewModel.saveNotifications(
                        notifyPrivate, notifyGroup, notifyInvites,
                        soundEnabled, vibrationEnabled, showPreview
                    )
                    onNavigateBack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Notification Preferences")
            }
        }
    }
}

@Composable
private fun NotificationToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
