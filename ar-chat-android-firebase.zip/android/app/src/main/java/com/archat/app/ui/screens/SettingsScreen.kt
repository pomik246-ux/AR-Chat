package com.archat.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.archat.app.ui.components.UserAvatar
import com.archat.app.ui.theme.DangerRed
import com.archat.app.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsContent(
    settingsViewModel: SettingsViewModel,
    onEditProfile: () -> Unit,
    onPrivacySettings: () -> Unit,
    onBlockedUsers: () -> Unit,
    onNotificationSettings: () -> Unit
) {
    val profile by settingsViewModel.myProfile.collectAsStateWithLifecycle()
    val privateInfo by settingsViewModel.privateInfo.collectAsStateWithLifecycle()
    val blockedUsers by settingsViewModel.blockedUsers.collectAsStateWithLifecycle()
    val darkOverride by settingsViewModel.isDarkModeOverride.collectAsStateWithLifecycle()
    val isSystemDark = isSystemInDarkTheme()
    val effectiveDark = darkOverride ?: isSystemDark

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onEditProfile)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(
                photoUrl = profile?.photoUrl ?: "",
                displayName = profile?.displayName ?: "AR",
                size = 62.dp
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = profile?.displayName ?: "Loading...",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "@${profile?.username ?: ""} · ${privateInfo?.email ?: ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = profile?.bio ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(Icons.Filled.Edit, contentDescription = "Edit profile")
        }

        HorizontalDivider()

        SettingsRow(
            icon = Icons.Filled.Lock,
            title = "Privacy",
            subtitle = "Last seen, online status, profile photo visibility",
            onClick = onPrivacySettings
        )
        SettingsRow(
            icon = Icons.Filled.Notifications,
            title = "Notifications",
            subtitle = "Message alerts, group notifications, previews",
            onClick = onNotificationSettings
        )
        SettingsRow(
            icon = Icons.Filled.Block,
            title = "Blocked Users",
            subtitle = "${blockedUsers.size} blocked contact(s)",
            onClick = onBlockedUsers
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Dark Theme", style = MaterialTheme.typography.titleMedium)
                Text("Switch between crisp white and dark mode", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
                checked = effectiveDark,
                onCheckedChange = { settingsViewModel.setDarkMode(it) }
            )
        }

        HorizontalDivider()

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { settingsViewModel.logout() }
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = DangerRed)
            Spacer(Modifier.width(16.dp))
            Text("Sign Out", style = MaterialTheme.typography.titleMedium, color = DangerRed)
        }
    }
}

@Composable
private fun SettingsRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
