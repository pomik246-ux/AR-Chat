package com.archat.app.data.repository

import android.content.Context
import android.net.Uri
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.io.File
import java.util.UUID

sealed class UploadProgress {
    data class InProgress(val fraction: Float) : UploadProgress()
    data class Success(val downloadUrl: String) : UploadProgress()
    data class Failure(val message: String) : UploadProgress()
}

class StorageRepository(
    private val storage: FirebaseStorage,
    private val context: Context
) {
    suspend fun uploadProfilePhoto(uid: String, imageUri: Uri): Result<String> = runCatching {
        val ref = storage.reference.child("profile_photos/$uid/avatar_${System.currentTimeMillis()}.jpg")
        val bytes = context.contentResolver.openInputStream(imageUri)?.use { it.readBytes() }
            ?: error("Unable to read selected image")
        ref.putBytes(bytes).await()
        ref.downloadUrl.await().toString()
    }

    suspend fun uploadGroupPhoto(groupId: String, imageUri: Uri): Result<String> = runCatching {
        val ref = storage.reference.child("group_photos/$groupId/icon_${System.currentTimeMillis()}.jpg")
        val bytes = context.contentResolver.openInputStream(imageUri)?.use { it.readBytes() }
            ?: error("Unable to read selected image")
        ref.putBytes(bytes).await()
        ref.downloadUrl.await().toString()
    }

    fun uploadChatImage(chatId: String, senderId: String, imageUri: Uri, isGroup: Boolean = false): Flow<UploadProgress> = callbackFlow {
        val folder = if (isGroup) "group_media" else "chat_media"
        val ref = storage.reference.child("$folder/$chatId/$senderId/img_${UUID.randomUUID()}.jpg")
        val task = ref.putFile(imageUri)

        task.addOnProgressListener { snap ->
            val total = snap.totalByteCount.coerceAtLeast(1L)
            trySend(UploadProgress.InProgress(snap.bytesTransferred.toFloat() / total.toFloat()))
        }.addOnSuccessListener {
            ref.downloadUrl.addOnSuccessListener { url ->
                trySend(UploadProgress.Success(url.toString()))
                close()
            }.addOnFailureListener { e ->
                trySend(UploadProgress.Failure(e.localizedMessage ?: "Failed to retrieve image URL"))
                close()
            }
        }.addOnFailureListener { e ->
            trySend(UploadProgress.Failure(e.localizedMessage ?: "Image upload failed"))
            close()
        }

        awaitClose {
            if (task.isInProgress) task.cancel()
        }
    }

    fun uploadVoiceNote(chatId: String, senderId: String, audioFile: File, isGroup: Boolean = false): Flow<UploadProgress> = callbackFlow {
        val folder = if (isGroup) "group_media" else "chat_media"
        val ref = storage.reference.child("$folder/$chatId/$senderId/voice_${UUID.randomUUID()}.m4a")
        val task = ref.putFile(Uri.fromFile(audioFile))

        task.addOnProgressListener { snap ->
            val total = snap.totalByteCount.coerceAtLeast(1L)
            trySend(UploadProgress.InProgress(snap.bytesTransferred.toFloat() / total.toFloat()))
        }.addOnSuccessListener {
            ref.downloadUrl.addOnSuccessListener { url ->
                trySend(UploadProgress.Success(url.toString()))
                close()
            }.addOnFailureListener { e ->
                trySend(UploadProgress.Failure(e.localizedMessage ?: "Failed to retrieve audio URL"))
                close()
            }
        }.addOnFailureListener { e ->
            trySend(UploadProgress.Failure(e.localizedMessage ?: "Audio upload failed"))
            close()
        }

        awaitClose {
            if (task.isInProgress) task.cancel()
        }
    }
}
